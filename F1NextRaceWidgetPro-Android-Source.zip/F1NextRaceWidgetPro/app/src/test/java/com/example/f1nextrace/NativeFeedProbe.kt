package com.example.f1nextrace

import org.json.JSONObject
import java.time.Instant
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/** Run the exact app transport on a desktop JVM when a CI host is blocked by the data provider. */
fun main(args: Array<String>) {
    val race = RaceInfo("Singapore Grand Prix", "Marina Bay", "Singapore", Instant.parse(args.firstOrNull() ?: "2026-10-11T12:00:00Z"))
    val state = LiveTimingState()
    val latch = CountDownLatch(1)
    val lock = Any()
    var messages = 0
    var failure = "none"
    var report = JSONObject().put("live", false)
    val client = LiveTimingClient({ topic, data, timestamp ->
        synchronized(lock) {
            val elapsed = System.nanoTime() / 1_000_000L
            state.accept(topic, data, timestamp, elapsed)
            if (topic == "TimingData" && timestamp != null) messages++
            report = state.display(race, System.currentTimeMillis(), elapsed)
            if (report.optBoolean("live") && messages >= 3) latch.countDown()
        }
    }, { reason -> synchronized(lock) { failure = reason }; latch.countDown() })
    client.connect()
    latch.await(45, TimeUnit.SECONDS)
    val valid = synchronized(lock) {
        println(JSONObject().put("failure", failure).put("messages", messages)
            .put("authenticated", false).put("state", report).toString(2))
        report.optBoolean("live") && messages >= 3
    }
    client.close()
    exitProcess(if (valid) 0 else 1)
}
