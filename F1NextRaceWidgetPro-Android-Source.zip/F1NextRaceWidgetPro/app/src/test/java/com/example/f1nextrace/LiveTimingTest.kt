package com.example.f1nextrace

import okhttp3.*
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.Instant
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class LiveTimingTest {
    private val start = Instant.parse("2026-10-11T12:00:00Z")
    private val now = start.toEpochMilli()
    private val race = RaceInfo("Singapore Grand Prix", "Marina Bay", "Singapore", start)

    @Test fun sparsePatchesKeepNamesAndReorderOvertakes() {
        val state = timingFixture(now)
        state.accept("TimingData", JSONObject("""{"Lines":{"1":{"Position":"2","GapToLeader":"+0.300"},"2":{"Position":"1"}}}"""), start.plusSeconds(1).toString(),101_000L)
        val data = state.display(race,now+1_000L,101_000L)
        assertTrue(data.getBoolean("live"))
        assertEquals("1  LECLERC   LEADER",data.getJSONArray("rows").getString(0))
        assertEquals("2  VERSTAPPEN   +0.300",data.getJSONArray("rows").getString(1))
    }
    @Test fun staleWrongSessionAndDuplicatePositionsCannotBeLive() {
        val state = timingFixture(now)
        assertFalse(state.display(race,now+31_000L,131_000L).getBoolean("live"))
        assertFalse(state.display(race.copy(start=start.plusSeconds(86400)),now,100_000L).getBoolean("live"))
        state.accept("TimingData",JSONObject("""{"Lines":{"2":{"Position":"1"}}}"""),start.toString(),100_000L)
        assertFalse(state.display(race,now,100_000L).getBoolean("live"))
        state.accept("SessionInfo",JSONObject("""{"Key":11389,"Type":"Qualifying"}"""),null,100_000L)
        assertEquals(0,state.display(race,now,100_000L).getJSONArray("rows").length())
    }
    @Test fun snapshotOnlyIsNotVerifiedLiveAndFinishStopsLiveLabel() {
        val state = timingFixture(now)
        state.accept("SessionStatus",JSONObject("""{"Status":"Finished"}"""),null,100_000L)
        assertTrue(state.display(race,now,100_000L).getBoolean("finished"))
        assertFalse(state.display(race,now,100_000L).getBoolean("live"))
        val blank = LiveTimingState()
        blank.accept("TimingData",JSONObject("""{"Lines":{}}"""),null,100_000L)
        assertFalse(blank.display(race,now,100_000L).getBoolean("live"))
    }

    @Test fun nativeClientNegotiatesCookieSubscribesAndMergesFramedMessages() {
        val server = MockWebServer()
        val delivered = CountDownLatch(2)
        val received = mutableListOf<String>()
        val errors = AtomicInteger()
        server.enqueue(MockResponse().setResponseCode(405).setHeader("Set-Cookie","AWSALBCORS=test-affinity; Path=/"))
        server.enqueue(MockResponse().setBody("""{"connectionToken":"test connection","connectionId":"id"}"""))
        server.enqueue(MockResponse().withWebSocketUpgrade(object: WebSocketListener() {
            override fun onMessage(ws: WebSocket, text: String) {
                val message = JSONObject(text.trimEnd('\u001e'))
                if (message.has("protocol")) ws.send("{}\u001e")
                else if (message.optString("target") == "Subscribe") {
                    ws.send("{\"type\":3,\"invocationId\":\"1\",\"result\":{\"SessionStatus\":{\"Status\":\"Started\"}}}\u001e" +
                        "{\"type\":1,\"target\":\"feed\",\"arguments\":[\"LapCount\",{\"CurrentLap\":3},\"2026-10-11T12:05:00Z\"]}\u001e")
                }
            }
        }))
        server.start()
        val client = LiveTimingClient({ topic, _, timestamp ->
            synchronized(received) { received.add("$topic:${timestamp ?: "snapshot"}") }
            delivered.countDown()
        }, { errors.incrementAndGet() }, server.url("/signalrcore").toString())
        try {
            client.connect()
            assertTrue("No snapshot/feed received",delivered.await(15,TimeUnit.SECONDS))
            val options=server.takeRequest(1,TimeUnit.SECONDS)!!
            val negotiate=server.takeRequest(1,TimeUnit.SECONDS)!!
            val upgrade=server.takeRequest(1,TimeUnit.SECONDS)!!
            assertEquals("OPTIONS",options.method)
            assertEquals("POST",negotiate.method)
            assertEquals("AWSALBCORS=test-affinity",negotiate.getHeader("Cookie"))
            assertTrue(upgrade.path!!.contains("id=test%20connection"))
            assertNull(upgrade.getHeader("Authorization"))
            assertEquals(listOf("SessionStatus:snapshot","LapCount:2026-10-11T12:05:00Z"),received)
            assertEquals(0,errors.get())
        } finally { client.close(); server.shutdown() }
    }

    @Test fun nativeClientReportsRejectedFeed() {
        val server = MockWebServer()
        server.enqueue(MockResponse())
        server.enqueue(MockResponse().setResponseCode(401))
        server.start()
        val failed=CountDownLatch(1)
        val client=LiveTimingClient({_,_,_->fail("Unauthorized data")},{failed.countDown()},server.url("/signalrcore").toString())
        try { client.connect(); assertTrue(failed.await(10,TimeUnit.SECONDS)) }
        finally { client.close();server.shutdown() }
    }

    @Test fun boundedPublicFeedDiagnostic() {
        // Report real transport availability independently of deterministic tests.
        // This one-time 2026 Singapore probe expires; external outages do not break future builds.
        if (!NextRaceWidgetProvider.liveWindow(race,System.currentTimeMillis())) return
        val state=LiveTimingState()
        val finished=CountDownLatch(1)
        val messages=AtomicInteger()
        var report=JSONObject().put("live",false)
        var failure="none"
        val lock=Any()
        val client=LiveTimingClient({topic,data,timestamp ->
            synchronized(lock) {
                val elapsed=System.nanoTime()/1_000_000L
                state.accept(topic,data,timestamp,elapsed)
                if (topic=="TimingData" && timestamp!=null) messages.incrementAndGet()
                report=state.display(race,System.currentTimeMillis(),elapsed)
                if (report.optBoolean("live") && messages.get()>=3) finished.countDown()
            }
        }, { reason -> synchronized(lock) { failure=reason }; finished.countDown() })
        try {
            client.connect();finished.await(45,TimeUnit.SECONDS)
            synchronized(lock) { println("NATIVE_LIVE_PROBE failure=$failure messages=${messages.get()} $report") }
        } finally { client.close() }
    }
}
