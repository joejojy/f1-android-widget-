package com.example.f1nextrace

import android.content.Context
import android.os.SystemClock
import android.view.View
import android.widget.Chronometer
import android.widget.FrameLayout
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.Robolectric
import org.robolectric.shadows.ShadowLooper
import android.app.Activity
import java.util.concurrent.TimeUnit
import java.time.Instant
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class WidgetTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private var nowMillis = Instant.parse("2026-10-11T08:51:00Z").toEpochMilli()

    @Before fun resetCache() {
        context.getSharedPreferences("f1_race_cache", Context.MODE_PRIVATE).edit().clear().commit()
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Kolkata"))
    }

    private fun cache(start: Instant, name: String = "Singapore Grand Prix") {
        context.getSharedPreferences("f1_race_cache", Context.MODE_PRIVATE).edit()
            .putString("start", start.toString()).putString("name", name)
            .putString("locality", "Marina Bay").putString("country", "Singapore")
            .putLong("updated", System.currentTimeMillis()).commit()
    }

    private fun render(): View = NextRaceWidgetProvider.renderWidget(context, nowMillis)
        .apply(context, FrameLayout(context))

    @Test fun nativeClockUsesActualStartInsteadOfCachedCountdown() {
        cache(Instant.ofEpochMilli(nowMillis + 11_340_000L))
        val clock = render().findViewById<Chronometer>(R.id.countdown)
        assertEquals(11_340_000L, clock.base - SystemClock.elapsedRealtime())
        assertFalse(clock.isCountDown)
        assertTrue(clock.text.toString().contains("3:09:00"))
        assertTrue(clock.text.toString().contains("-"))
        // Re-rendering must derive remaining time from the start, not cached minutes.
        SystemClock.sleep(240_000L)
        nowMillis += 240_000L
        val later = render().findViewById<Chronometer>(R.id.countdown)
        assertEquals(11_100_000L, later.base - SystemClock.elapsedRealtime())
        assertTrue(later.text.toString().contains("3:05:00"))
    }

    @Test fun signedClockHandlesZeroAndPastStartWithoutClaimingLiveData() {
        cache(Instant.ofEpochMilli(nowMillis))
        assertTrue(render().findViewById<Chronometer>(R.id.countdown).text.toString().contains("00:00"))
        cache(Instant.ofEpochMilli(nowMillis - 120_000L))
        val view = render()
        val text = view.findViewById<Chronometer>(R.id.countdown).text.toString()
        assertTrue(text.contains("02:00"))
        assertFalse(text.contains("-"))
        assertFalse(view.findViewById<TextView>(R.id.status).text.toString().contains("LIVE"))
    }

    @Test fun missingCacheShowsPlaceholder() {
        val view = render()
        assertEquals("SYNCING", view.findViewById<TextView>(R.id.status).text.toString())
        assertEquals("START  •  --:--:--", view.findViewById<Chronometer>(R.id.countdown).text.toString())
    }

    @Test fun footerAndClockFitMinimumAndTypicalWidgetSizes() {
        cache(Instant.ofEpochMilli(nowMillis + 1_209_600_000L),
            "Formula 1 Very Long Grand Prix Name")
        for ((width, height) in listOf(250 to 170, 340 to 185, 400 to 220)) {
            val view = render()
            val density = context.resources.displayMetrics.density
            val w = (width * density).toInt()
            val h = (height * density).toInt()
            view.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
            view.layout(0, 0, w, h)
            val footer = view.findViewById<TextView>(R.id.footer)
            val clock = view.findViewById<Chronometer>(R.id.countdown)
            val title = view.findViewById<TextView>(R.id.race_name)
            assertTrue("Footer clipped at $width x $height", footer.bottom <= h - view.paddingBottom)
            assertTrue("Footer overlaps clock", footer.top >= clock.bottom)
            assertTrue("Title collapsed", title.height >= (20 * density).toInt())
            assertTrue("Footer glyphs clipped: ${footer.layout.height} > ${footer.height}", footer.layout.height <= footer.height)
            assertTrue("Footer text too wide", footer.layout.getLineWidth(0) <= footer.width)
            assertTrue("Calendar action missing", footer.hasOnClickListeners())
        }
    }

    @Test fun attachedClockTicksAndCrossesStartWithoutProviderRefresh() {
        cache(Instant.ofEpochMilli(nowMillis + 2_000L))
        val view = render()
        val activity = Robolectric.buildActivity(Activity::class.java).setup().visible().get()
        activity.setContentView(view)
        val clock = view.findViewById<Chronometer>(R.id.countdown)
        assertTrue(clock.text.toString().contains("-00:02"))
        ShadowLooper.idleMainLooper(5, TimeUnit.SECONDS)
        assertTrue("Clock did not tick: ${clock.text}", clock.text.toString().contains("00:03"))
        assertFalse(clock.text.toString().contains("-"))
    }

    @Test fun timezoneChangeKeepsSameInstant() {
        cache(Instant.parse("2026-10-11T12:00:00Z"))
        val india = render()
        val base = india.findViewById<Chronometer>(R.id.countdown).base
        assertTrue(india.findViewById<TextView>(R.id.race_date).text.toString().contains("5:30 PM"))
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"))
        val london = render()
        assertEquals(base, london.findViewById<Chronometer>(R.id.countdown).base)
        assertTrue(london.findViewById<TextView>(R.id.race_date).text.toString().contains("1:00 PM"))
    }
}
