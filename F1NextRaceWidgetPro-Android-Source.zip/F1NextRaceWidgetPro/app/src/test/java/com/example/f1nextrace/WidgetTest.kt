package com.example.f1nextrace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class WidgetTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private val start = Instant.parse("2026-10-11T12:00:00Z")
    private val race = RaceInfo("Singapore Grand Prix", "Marina Bay", "Singapore", start, "marina_bay", "Marina Bay")
    @Before fun reset() {
        listOf("f1_race_cache", "f1_live").forEach {
            context.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Kolkata"))
    }
    private fun render(now: Long, elapsed: Long = 100_000L, width: Int = 340, height: Int = 185): View {
        val view = NextRaceWidgetProvider.renderWidget(context, now, elapsed, showTrack = width >= 320)
            .apply(context, FrameLayout(context))
        val density = context.resources.displayMetrics.density
        val w = (width * density).toInt(); val h = (height * density).toInt()
        view.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
        view.layout(0, 0, w, h)
        return view
    }
    private fun bounds(root: View, id: Int): Rect {
        val child = root.findViewById<View>(id)
        return Rect(0,0,child.width,child.height).also { (root as ViewGroup).offsetDescendantRectToMyCoords(child, it) }
    }
    @Test fun minuteCountdownRecomputesFromInstantAndNeverCountsUp() {
        RaceRepository.save(context, race)
        val before = start.toEpochMilli() - 11_340_000L
        assertEquals("START IN  •  3h 9m", render(before).findViewById<TextView>(R.id.countdown).text.toString())
        assertEquals("START IN  •  3h 5m", render(before + 240_000L).findViewById<TextView>(R.id.countdown).text.toString())
        assertEquals("START IN  •  0h 1m", NextRaceWidgetProvider.countdown(60_000L, 59_999L))
        for (now in listOf(start.toEpochMilli(), start.toEpochMilli() + 120_000L)) {
            val view = render(now)
            assertEquals("SCHEDULED START REACHED", view.findViewById<TextView>(R.id.countdown).text.toString())
            assertEquals(View.VISIBLE, view.findViewById<View>(R.id.live_action).visibility)
            assertEquals("START LIVE  ▶", view.findViewById<TextView>(R.id.live_action).text.toString())
            assertFalse(view.findViewById<TextView>(R.id.status).text.contains("LIVE"))
        }
    }
    @Test fun missingCacheAndTimezoneChange() {
        assertEquals("START IN  •  —", render(0L).findViewById<TextView>(R.id.countdown).text.toString())
        RaceRepository.save(context, race)
        val now = start.toEpochMilli() - 3600_000L
        val india = render(now)
        assertTrue(india.findViewById<TextView>(R.id.race_date).text.contains("5:30 PM"))
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"))
        val london = render(now)
        assertTrue(london.findViewById<TextView>(R.id.race_date).text.contains("1:00 PM"))
        assertEquals(india.findViewById<TextView>(R.id.countdown).text, london.findViewById<TextView>(R.id.countdown).text)
    }
    @Test fun liveRowsFitAllSizesAndStaleNeverSaysLive() {
        RaceRepository.save(context, race)
        val now = start.toEpochMilli()
        LiveCache.save(context, timingFixture(now).display(race, now, 100_000L).put("running", true))
        for ((w,h) in listOf(250 to 170, 320 to 170, 340 to 185, 400 to 220)) {
            val view = render(now, width=w, height=h)
            assertEquals(View.GONE, view.findViewById<View>(R.id.race_details).visibility)
            assertTrue(view.findViewById<TextView>(R.id.status).text.startsWith("LIVE"))
            assertTrue(bounds(view, R.id.driver_5).bottom <= bounds(view, R.id.footer).top)
            assertTrue(bounds(view, R.id.footer).bottom <= view.height - view.paddingBottom)
            for (id in listOf(R.id.driver_1, R.id.driver_2, R.id.driver_3, R.id.driver_4, R.id.driver_5, R.id.footer, R.id.live_action)) {
                val text = view.findViewById<TextView>(id)
                assertTrue("Text too wide: $id at $w", text.layout.getLineWidth(0) <= text.width)
                assertTrue("Text too tall: $id at $w", text.layout.height <= text.height)
            }
            if (w == 340) {
                val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
                view.draw(Canvas(bitmap))
                val out = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.PNG,100,out)
                Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP).chunked(10000)
                    .forEachIndexed { i, data -> println("WIDGET_PREVIEW_live_${i} $data") }
            }
        }
        val saved = LiveCache.read(context)!!.put("tickWall", now + 25_000L).put("tickElapsed", 125_000L)
        LiveCache.save(context, saved)
        assertEquals("STALE DATA", render(now + 35_000L, 135_000L).findViewById<TextView>(R.id.status).text.toString())
        assertEquals("LAST KNOWN", render(now + 70_000L, 170_000L).findViewById<TextView>(R.id.status).text.toString())
        assertFalse(LiveCache.active(saved, now + 35_000L, 100L))
        RaceRepository.save(context, race.copy(start = start.plusSeconds(86400)))
        assertEquals(View.GONE, render(now).findViewById<View>(R.id.live_rows).visibility)
    }
    @Test fun currentRaceRemainsAvailableForFourHours() {
        val calendar = javaClass.getResourceAsStream("/calendar-2026.json")!!.bufferedReader().readText()
        assertEquals("marina_bay", RaceRepository.parseNextRace(calendar, start.plusSeconds(1)).circuitId)
        assertEquals("americas", RaceRepository.parseNextRace(calendar, start.plusSeconds(4*3600)).circuitId)
    }
}

internal fun timingFixture(now: Long): LiveTimingState = LiveTimingState().apply {
    accept("SessionInfo", JSONObject("""{"Key":11388,"Type":"Race","StartDate":"2026-10-11T20:00:00","GmtOffset":"08:00:00"}"""), null, 100_000L)
    accept("SessionStatus", JSONObject("""{"Status":"Started"}"""), null, 100_000L)
    accept("LapCount", JSONObject("""{"CurrentLap":1,"TotalLaps":62}"""), null, 100_000L)
    val drivers = JSONObject(); val lines = JSONObject()
    listOf("VERSTAPPEN", "LECLERC", "HAMILTON", "ANTONELLI", "NORRIS").forEachIndexed { i, name ->
        drivers.put("${i+1}", JSONObject().put("LastName", name))
        lines.put("${i+1}", JSONObject().put("Position", "${i+1}").put("GapToLeader", "+0.259"))
    }
    accept("DriverList", drivers, null, 100_000L)
    accept("TimingData", JSONObject().put("Lines",lines), Instant.ofEpochMilli(now).toString(),100_000L)
}
