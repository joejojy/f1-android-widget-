package com.example.f1nextrace

import android.app.AlarmManager
import android.app.Application
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlarmManager
import java.time.Instant
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class AutoLiveTest {
    private val context: Application get() = RuntimeEnvironment.getApplication()
    private val alarms get() = context.getSystemService(AlarmManager::class.java)
    private val race = RaceInfo("Singapore Grand Prix", "Marina Bay", "Singapore", Instant.parse("2026-10-11T12:00:00Z"))
    private val now = race.start.toEpochMilli()
    private fun bindWidget() = shadowOf(AppWidgetManager.getInstance(context))
        .bindAppWidgetId(1,ComponentName(context,NextRaceWidgetProvider::class.java))
    private fun raceAlarms() = shadowOf(alarms).scheduledAlarms.filter {
        it.operation != null && shadowOf(it.operation).savedIntent.action == AutoLiveScheduler.ACTION_START
    }
    private fun alarmIntent() = Intent(context,AutoLiveAlarmReceiver::class.java)
        .setAction(AutoLiveScheduler.ACTION_START).putExtra(AutoLiveScheduler.EXTRA_RACE,race.start.toString())

    @Before fun reset() {
        listOf("f1_race_cache","f1_auto_live","f1_live").forEach {
            context.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit()
        }
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        RaceRepository.save(context,race)
    }

    @Test fun optInPermissionAndWidgetAreRequired() {
        bindWidget()
        AutoLiveScheduler.schedule(context,now-600_000L)
        assertTrue(raceAlarms().isEmpty())
        AutoLiveScheduler.setEnabled(context,true)
        ShadowAlarmManager.setCanScheduleExactAlarms(false)
        AutoLiveScheduler.schedule(context,now-600_000L)
        assertTrue(raceAlarms().isEmpty())
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        AutoLiveScheduler.schedule(context,now-600_000L)
        assertEquals(1,raceAlarms().size)
        AutoLiveScheduler.setEnabled(context,false)
        assertTrue(raceAlarms().isEmpty())
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now)
        assertNull(shadowOf(context).nextStartedService)
    }

    @Test fun noWidgetNeverSchedulesEvenWhenEnabled() {
        AutoLiveScheduler.setEnabled(context,true)
        AutoLiveScheduler.schedule(context,now-60_000L)
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now)
        assertTrue(raceAlarms().isEmpty())
        assertNull(shadowOf(context).nextStartedService)
    }

    @Test fun exactRaceAlarmUsesUtcAndRestoresAfterSystemAlarmLoss() {
        bindWidget();AutoLiveScheduler.setEnabled(context,true)
        AutoLiveScheduler.schedule(context,now-60_000L)
        val alarm=raceAlarms().single()
        assertEquals(AlarmManager.RTC_WAKEUP,alarm.type)
        assertEquals(now,alarm.triggerAtMs)
        assertEquals(0L,alarm.windowLengthMs)
        assertTrue(alarm.allowWhileIdle)
        assertEquals(0L,alarm.intervalMs)
        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"))
        AutoLiveScheduler.schedule(context,now-30_000L)
        assertEquals(now,raceAlarms().single().triggerAtMs)
        alarms.cancelAll() // Android removes alarms at reboot; preferences survive.
        AutoLiveScheduler.schedule(context,now-10_000L)
        assertEquals(now,raceAlarms().single().triggerAtMs)
        RaceRepository.save(context,race.copy(start=race.start.plusSeconds(3600)))
        AutoLiveScheduler.schedule(context,now-10_000L)
        assertEquals(now+3_600_000L,raceAlarms().single().triggerAtMs)
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now)
        assertNull(shadowOf(context).nextStartedService) // old race alarm cannot start new race
    }

    @Test fun alarmStartsForegroundServiceOnlyOnceAndNextRaceStillArms() {
        bindWidget();AutoLiveScheduler.setEnabled(context,true)
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now-1)
        assertNull(shadowOf(context).nextStartedService)
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now)
        assertEquals(LiveRaceService::class.java.name,shadowOf(context).nextStartedService.component!!.className)
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now+1_000L)
        assertNull(shadowOf(context).nextStartedService)
        AutoLiveScheduler.schedule(context,now+60_000L)
        assertTrue(raceAlarms().isEmpty())
        RaceRepository.save(context,race.copy(start=race.start.plusSeconds(14*86400L)))
        AutoLiveScheduler.schedule(context,now+60_000L)
        assertEquals(1,raceAlarms().size)
    }

    @Test fun stopSuppressesThisRaceAndLateEnableHasBoundedCatchUp() {
        bindWidget();AutoLiveScheduler.setEnabled(context,true)
        AutoLiveScheduler.schedule(context,now+60_000L)
        assertEquals(now+61_000L,raceAlarms().single().triggerAtMs)
        NextRaceWidgetProvider().onReceive(context,Intent(context,NextRaceWidgetProvider::class.java)
            .setAction(NextRaceWidgetProvider.STOP_LIVE))
        assertTrue(AutoLiveScheduler.enabled(context))
        AutoLiveScheduler.startFromAlarm(context,alarmIntent(),now+61_000L)
        assertNull(shadowOf(context).nextStartedService)
        AutoLiveScheduler.schedule(context,now+120_000L)
        assertTrue(raceAlarms().isEmpty())
        assertNull(AutoLiveScheduler.triggerTime(race,now+14_400_000L,true,true,true,false))
    }
}
