package com.example.f1nextrace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.time.Instant

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],qualifiers="xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class FlatWidgetTest {
    private val c: Context get()=RuntimeEnvironment.getApplication()
    private fun fixture() {
        for(name in listOf("f1_history","f1_live","f1_race_cache")) c.getSharedPreferences(name,0).edit().clear().commit()
        RaceRepository.save(c,RaceInfo("Singapore Grand Prix","Marina Bay","Singapore",Instant.now().plusSeconds(9720),"marina_bay"))
        SessionHistory.save(c,listOf(JSONObject().put("session_key",7).put("session_name","Race")
            .put("location","Singapore Grand Prix").put("date_start","2026-10-11T12:00:00Z")
            .put("fetched",1791799200000L).put("rows",JSONArray((1..5).map { n ->
                JSONObject().put("position",n).put("name",listOf("VERSTAPPEN","LECLERC","HAMILTON","ANTONELLI","NORRIS")[n-1])
                    .put("gap_to_leader",n*2.25)
            }))))
    }
    private fun measure(v: View,w: Int,h: Int) {
        val density=c.resources.displayMetrics.density
        v.measure(View.MeasureSpec.makeMeasureSpec((w*density).toInt(),View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec((h*density).toInt(),View.MeasureSpec.EXACTLY))
        v.layout(0,0,v.measuredWidth,v.measuredHeight)
    }
    private fun checkViewport(w: Int,h: Int,export: Boolean) {
        fixture()
        val root=WidgetDeck.sizedRoot(c,42,w,h).apply(c,FrameLayout(c))
        val list=root.findViewById<ListView>(R.id.cards)
        val factory=HistoryViewsService.Factory(c,42,w,h);factory.onCreate()
        // The real ListView measures factory-produced RemoteViews under list row constraints.
        list.adapter=object: BaseAdapter() {
            override fun getCount()=factory.getCount()
            override fun getItem(position: Int)=position
            override fun getItemId(position: Int)=factory.getItemId(position)
            override fun getView(position: Int,convertView: View?,parent: ViewGroup): View {
                val views=factory.getViewAt(position)
                return if(convertView==null) views.apply(c,parent) else convertView.also { views.reapply(c,it) }
            }
        }
        for(page in 0..1) {
            list.setSelection(page)
            measure(root,w,h)
            val child=list.getChildAt(0)
            assertEquals("full width",list.width,child.width)
            assertEquals("full height",list.height,child.height)
            assertEquals("no scale",1f,child.scaleX,0f)
            assertEquals("no top inset",0,child.top)
            assertEquals("one screen visible",1,(0 until list.childCount).count { list.getChildAt(it).top<list.height && list.getChildAt(it).bottom>0 })
            if(page==0) {
                val title=child.findViewById<View>(R.id.race_name)
                val details=child.findViewById<View>(R.id.details_row)
                val density=c.resources.displayMetrics.density
                assertTrue("title uses a balanced share of the viewport",title.height < child.height*.25f)
                val heading=child.findViewById<View>(R.id.session_heading)
                val header=heading.parent as View
                assertTrue("title stays next to heading",title.top-header.bottom<=3*density)
                assertTrue("details stay close to title",details.top-title.bottom<=3*density)
                assertTrue("reference edge inset",title.left>=10*density)
                val footer=child.findViewById<View>(R.id.footer_row)
                assertTrue("no dead spacer before footer",footer.top-details.bottom<=density)
                // Fractional layout weights can leave one physical pixel after rounding.
                assertTrue("footer stays near lower edge",kotlin.math.abs(child.height-footer.bottom-(10*density).toInt())<=1)
            }
            val ids=if(page==0) listOf(R.id.session_heading,R.id.race_name,R.id.countdown,R.id.footer)
                else listOf(R.id.result_title,R.id.result_1,R.id.result_2,R.id.result_3,R.id.result_footer)
            for(id in ids) {
                val text=child.findViewById<TextView>(id)
                assertTrue("height $id at $w x $h",text.layout.height<=text.height)
                assertTrue("width $id at $w x $h",text.layout.getLineWidth(0)<=text.width)
            }
            if(export) {
                val bitmap=Bitmap.createBitmap(root.width,root.height,Bitmap.Config.ARGB_8888)
                root.draw(Canvas(bitmap))
                val file=java.io.File("build/previews/flat-${if(page==0) "home" else "results"}-${w}x${h}.png")
                file.parentFile!!.mkdirs()
                file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }
            }
        }
        list.setSelection(0);measure(root,w,h)
        list.scrollListBy(list.height/2)
        assertTrue("swipe scrolling moves the content",list.getChildAt(0).top<0)
    }
    @Test fun fullWidgetFillsCompactAndLargeViewportsWithoutStacking() {
        for((w,h) in listOf(200 to 150,250 to 170,340 to 170,340 to 220,400 to 300)) checkViewport(w,h,true)
    }
    @Test @Config(sdk=[28]) fun heightStrutWorksBeforeAndroid12() { checkViewport(250,170,false) }

    private fun checkRepeatedUpdates() {
        fixture()
        val factory=HistoryViewsService.Factory(c,42,340,170);factory.onCreate()
        val parent=FrameLayout(c)
        // Start with the loading state, as on a fresh installation.
        c.getSharedPreferences("f1_race_cache",0).edit().clear().commit()
        val row=factory.getViewAt(0).apply(c,parent)
        repeat(30) { update ->
            val name="Updated Grand Prix $update"
            RaceRepository.save(c,RaceInfo(name,"New circuit","New country",Instant.now().plusSeconds(7200-update*60L),"americas"))
            factory.getViewAt(0).reapply(c,row)
            measure(row,340,170)
            assertEquals("refresh must replace previous screen",1,row.findViewById<ViewGroup>(R.id.page_content).childCount)
            assertEquals(name,row.findViewById<TextView>(R.id.race_name).text.toString())
            // Recycle the same row for results, then back to Home.
            factory.getViewAt(1).reapply(c,row)
            assertEquals(1,row.findViewById<ViewGroup>(R.id.page_content).childCount)
            assertNull(row.findViewById<View>(R.id.race_name))
            assertEquals("Singapore Grand Prix",row.findViewById<TextView>(R.id.result_title).text.toString())
            factory.getViewAt(0).reapply(c,row)
            assertNull(row.findViewById<View>(R.id.result_title))
            assertEquals(1,row.findViewById<ViewGroup>(R.id.page_content).childCount)
        }
    }
    @Test fun repeatedRefreshesReplaceOldContentsAndRecycledPages() { checkRepeatedUpdates() }
    @Test @Config(sdk=[28]) fun repeatedRefreshesReplaceOldContentsOnAndroid9() { checkRepeatedUpdates() }
}
