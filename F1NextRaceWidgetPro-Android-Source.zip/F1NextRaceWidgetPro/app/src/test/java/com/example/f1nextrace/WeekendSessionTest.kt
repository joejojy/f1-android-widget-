package com.example.f1nextrace

import android.app.AlarmManager
import android.app.Application
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlarmManager
import java.time.Instant

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],qualifiers="xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class WeekendSessionTest {
    private val context: Application get()=RuntimeEnvironment.getApplication()
    private val calendar get()=javaClass.getResourceAsStream("/calendar-2026.json")!!.bufferedReader().readText()
    private val start=Instant.parse("2026-10-11T12:00:00Z")
    private val race=RaceInfo("Singapore Grand Prix","Marina Bay","Singapore",start,"marina_bay","Marina Bay")
    @Before fun reset() {
        listOf("f1_race_cache","f1_auto_live","f1_live").forEach {
            context.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit()
        }
    }

    @Test fun regularAndSprintWeekendsHaveCorrectOrderedSessionsAndSkipMissingTimes() {
        val sessions=RaceRepository.parseSessions(calendar)
        assertEquals(listOf(SessionKind.PRACTICE_1,SessionKind.SPRINT_QUALIFYING,SessionKind.SPRINT,SessionKind.QUALIFYING,SessionKind.RACE),
            sessions.filter { it.circuitId=="marina_bay" }.map { it.kind })
        assertEquals(listOf(SessionKind.PRACTICE_1,SessionKind.PRACTICE_2,SessionKind.PRACTICE_3,SessionKind.QUALIFYING,SessionKind.RACE),
            sessions.filter { it.circuitId=="americas" }.map { it.kind })
        val json=JSONObject(calendar)
        val races=json.getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races")
        val sg=(0 until races.length()).map { races.getJSONObject(it) }.first { it.getString("raceName")=="Singapore Grand Prix" }
        sg.getJSONObject("FirstPractice").remove("time")
        sg.put("SprintShootout",sg.remove("SprintQualifying"))
        assertEquals(listOf(SessionKind.SPRINT_QUALIFYING,SessionKind.SPRINT,SessionKind.QUALIFYING,SessionKind.RACE),
            RaceRepository.parseSessions(json.toString()).filter { it.circuitId=="marina_bay" }.map { it.kind })
    }

    @Test fun offlineCalendarAdvancesAndStoppingPracticeStillArmsSprintQualifying() {
        val sessions=RaceRepository.parseSessions(calendar).filter { it.circuitId=="marina_bay" }
        val practice=sessions[0];val sq=sessions[1]
        context.getSharedPreferences("f1_race_cache",Context.MODE_PRIVATE).edit().putString("calendar",calendar).commit()
        assertEquals(practice,RaceRepository.cached(context,practice.start))
        assertEquals(sq,RaceRepository.cached(context,sq.start))
        assertEquals(sq,RaceRepository.nextForAuto(context,practice.start.plusSeconds(60),setOf(practice.sessionId)))
        RaceRepository.complete(context,practice)
        assertEquals(sq,RaceRepository.cached(context,practice.start.plusSeconds(60)))
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        shadowOf(AppWidgetManager.getInstance(context)).bindAppWidgetId(1,ComponentName(context,NextRaceWidgetProvider::class.java))
        AutoLiveScheduler.setEnabled(context,true)
        AutoLiveScheduler.markHandled(context,practice)
        AutoLiveScheduler.schedule(context,practice.start.plusSeconds(60).toEpochMilli())
        val alarm=shadowOf(context.getSystemService(AlarmManager::class.java)).scheduledAlarms.single()
        assertEquals(sq.start.toEpochMilli(),alarm.triggerAtMs)
        assertEquals(sq.sessionId,shadowOf(alarm.operation).savedIntent.getStringExtra(AutoLiveScheduler.EXTRA_RACE))
        assertTrue(AutoLiveScheduler.handled(context,practice))
        assertFalse(AutoLiveScheduler.handled(context,sq))
    }

    private fun state(kind: SessionKind): LiveTimingState = timingFixture(start.toEpochMilli()).apply {
        val type=if(kind.racing) "Race" else if(kind.qualifying) "Qualifying" else "Practice"
        val name=when(kind) {
            SessionKind.RACE -> "Race"
            SessionKind.SPRINT -> "Sprint"
            SessionKind.QUALIFYING -> "Qualifying"
            SessionKind.SPRINT_QUALIFYING -> "Sprint Qualifying"
            else -> "Practice ${kind.ordinal+1}"
        }
        accept("SessionInfo",JSONObject().put("Type",type).put("Name",name),null,100_000L)
        val lines=JSONObject()
        for(i in 1..5) lines.put(i.toString(),JSONObject().put("BestLapTime",JSONObject().put("Value","1:29.${i}23"))
            .put("BestLapTimes",JSONArray().put(JSONObject().put("Value","1:19.000"))
                .put(JSONObject().put("Value","1:25.000")).put(JSONObject().put("Value","1:30.${i}23"))))
        accept("TimingData",JSONObject().put("Lines",lines),null,100_000L)
        if(kind.qualifying) accept("SessionData",JSONObject().put("Series",JSONArray().put(JSONObject().put("QualifyingPart",3))),null,100_000L)
    }

    @Test fun qualifyingPartsUseTheirOwnTimesAndBreaksAreNotSessionEnd() {
        for(kind in listOf(SessionKind.QUALIFYING,SessionKind.SPRINT_QUALIFYING)) {
            val session=race.copy(kind=kind);val state=state(kind)
            var result=state.display(session,start.toEpochMilli(),100_000L)
            assertTrue(result.getBoolean("live"))
            assertTrue(result.getJSONArray("rows").getString(0).endsWith("1:30.123"))
            state.accept("TimingData",JSONObject("""{"Lines":{"1":{"BestLapTime":{"Value":"1:31.999"}}}}"""),start.toString(),100_000L)
            result=state.display(session,start.toEpochMilli(),100_000L)
            assertTrue(result.getJSONArray("rows").getString(0).endsWith("1:31.999"))
            state.accept("SessionStatus",JSONObject().put("Status","Finished"),null,100_000L)
            result=state.display(session,start.toEpochMilli(),100_000L)
            assertFalse(result.getBoolean("finished"))
            assertEquals("SESSION BREAK",result.getString("label"))
            state.accept("SessionStatus",JSONObject().put("Status","Finalised"),null,100_000L)
            assertTrue(state.display(session,start.toEpochMilli(),100_000L).getBoolean("finished"))
        }
        assertFalse(state(SessionKind.SPRINT).display(race,start.toEpochMilli(),100_000L).getBoolean("live"))
        assertFalse(state(SessionKind.PRACTICE_1).display(race.copy(kind=SessionKind.PRACTICE_2),start.toEpochMilli(),100_000L).getBoolean("live"))
        assertFalse(state(SessionKind.SPRINT_QUALIFYING).display(race.copy(kind=SessionKind.QUALIFYING),start.toEpochMilli(),100_000L).getBoolean("live"))
    }

    @Test fun everySessionRendersAppropriateTimingAndFitsSmallAndLargeWidgets() {
        for(kind in SessionKind.entries) {
            val session=race.copy(kind=kind)
            RaceRepository.save(context,session)
            assertEquals(kind,RaceRepository.cached(context)!!.kind)
            val result=state(kind).display(session,start.toEpochMilli(),100_000L).put("running",true)
            assertTrue("Not live for $kind",result.getBoolean("live"))
            val first=result.getJSONArray("rows").getString(0)
            assertTrue(if(kind.racing) first.endsWith("LEADER") else first.contains("1:"))
            LiveCache.save(context,result)
            for(width in listOf(250,320,340)) {
                val view=NextRaceWidgetProvider.renderWidget(context,start.toEpochMilli(),100_000L,width>=320)
                    .apply(context,FrameLayout(context))
                val density=context.resources.displayMetrics.density
                val w=(width*density).toInt();val h=(185*density).toInt()
                view.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY))
                view.layout(0,0,w,h)
                for(id in listOf(R.id.session_heading,R.id.driver_1,R.id.driver_5,R.id.status,R.id.footer,R.id.live_action)) {
                    val text=view.findViewById<TextView>(id)
                    assertTrue("Width $kind $id at $width",text.layout.getLineWidth(0)<=text.width)
                    assertTrue("Height $kind $id at $width",text.layout.height<=text.height)
                }
                if(width==340 && kind==SessionKind.SPRINT_QUALIFYING) {
                    val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);view.draw(Canvas(bitmap))
                    val output=java.io.ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,100,output)
                    java.util.Base64.getEncoder().encodeToString(output.toByteArray()).chunked(10000)
                        .forEachIndexed { i,data -> println("WIDGET_PREVIEW_qualifying_${i} $data") }
                }
            }
        }
    }
}
