package com.example.f1nextrace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.util.Base64
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CircuitLayoutTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private val now = Instant.parse("2026-10-11T09:18:56Z")
    private val calendar: String get() = javaClass.getResourceAsStream("/calendar-2026.json")!!
        .bufferedReader().use { it.readText() }

    @Before fun reset() {
        context.getSharedPreferences("f1_race_cache", Context.MODE_PRIVATE).edit().clear().commit()
        context.getSharedPreferences("f1_live", Context.MODE_PRIVATE).edit().clear().commit()
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Kolkata"))
    }

    private fun render(width: Int, height: Int): View {
        val view = NextRaceWidgetProvider.renderWidget(context, now.toEpochMilli(), showTrack = width >= 320)
            .apply(context, FrameLayout(context))
        val density = context.resources.displayMetrics.density
        val w = (width * density).toInt()
        val h = (height * density).toInt()
        view.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
        view.layout(0, 0, w, h)
        return view
    }

    private fun bounds(root: View, child: View): Rect {
        val r = Rect(0, 0, child.width, child.height)
        (root as android.view.ViewGroup).offsetDescendantRectToMyCoords(child, r)
        return r
    }

    @Test fun parsedCircuitSurvivesCacheAndChangesWithNextRace() {
        val singapore = RaceRepository.parseNextRace(calendar, now)
        assertEquals("marina_bay", singapore.circuitId)
        RaceRepository.save(context, singapore)
        assertEquals(singapore, RaceRepository.cached(context))
        val first = render(340, 185).findViewById<ImageView>(R.id.track_outline)
        assertEquals(View.VISIBLE, first.visibility)
        assertNotNull(first.drawable)
        assertTrue(first.contentDescription.toString().contains("Marina Bay"))
        val next = RaceRepository.parseNextRace(calendar, singapore.start.plusSeconds(4 * 3600))
        assertEquals("americas", next.circuitId)
        RaceRepository.save(context, next)
        assertEquals("americas", RaceRepository.cached(context)!!.circuitId)
        assertNotEquals(CircuitLayouts.resourceFor(singapore.circuitId), CircuitLayouts.resourceFor(next.circuitId))
        val second = render(340, 185).findViewById<ImageView>(R.id.track_outline)
        assertTrue(second.contentDescription.toString().contains("Americas"))
    }

    @Test fun everyCircuitInCurrentScheduleHasAnInflatableOutline() {
        val races = JSONObject(calendar).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races")
        for (i in 0 until races.length()) {
            val id = races.getJSONObject(i).getJSONObject("Circuit").getString("circuitId")
            val resource = CircuitLayouts.resourceFor(id)
            assertNotEquals("Missing circuit $id", 0, resource)
            assertNotNull(context.getDrawable(resource))
        }
    }

    @Test fun oldCacheAndUnknownTracksNeverShowAnIncorrectMap() {
        val singapore = RaceRepository.parseNextRace(calendar, now)
        RaceRepository.save(context, singapore)
        context.getSharedPreferences("f1_race_cache", Context.MODE_PRIVATE).edit()
            .remove("circuit_id").remove("circuit_name").commit()
        assertEquals("", RaceRepository.cached(context)!!.circuitId)
        assertEquals(View.GONE, render(340, 185).findViewById<View>(R.id.track_outline).visibility)
        RaceRepository.save(context, singapore.copy(circuitId = "unknown_future_track"))
        assertEquals(View.GONE, render(340, 185).findViewById<View>(R.id.track_outline).visibility)
        // Reapplying to an existing widget must hide the previous track as well.
        RaceRepository.save(context, singapore)
        val existing = render(340, 185)
        RaceRepository.save(context, singapore.copy(circuitId = ""))
        NextRaceWidgetProvider.renderWidget(context, now.toEpochMilli()).reapply(context, existing)
        assertEquals(View.GONE, existing.findViewById<View>(R.id.track_outline).visibility)
    }

    @Test fun mapAndTextDoNotOverlapAndCompactWidgetsKeepTextWidth() {
        RaceRepository.save(context, RaceRepository.parseNextRace(calendar, now))
        for ((w,h) in listOf(250 to 170, 320 to 170, 340 to 185, 400 to 220)) {
            val view = render(w,h)
            val map = view.findViewById<View>(R.id.track_outline)
            val footer = view.findViewById<TextView>(R.id.footer)
            val clock = view.findViewById<TextView>(R.id.countdown)
            assertTrue(bounds(view, footer).bottom <= view.height - view.paddingBottom)
            assertTrue(bounds(view, clock).bottom <= bounds(view, footer).top)
            if (w < 320) {
                assertEquals(View.GONE, map.visibility)
            } else {
                assertEquals(View.VISIBLE, map.visibility)
                assertTrue(bounds(view, clock).right < bounds(view, map).left)
                assertTrue(bounds(view, map).bottom <= bounds(view, footer).top)
            }
            for (id in listOf(R.id.countdown, R.id.race_date, R.id.footer)) {
                val text = view.findViewById<TextView>(id)
                assertTrue("Text too wide: $id at $w", text.layout.getLineWidth(0) <= text.width)
                assertTrue("Text too tall: $id at $w", text.layout.height <= text.height)
            }
        }
    }

    @Test fun renderPreviewImages() {
        val singapore = RaceRepository.parseNextRace(calendar, now)
        val next = RaceRepository.parseNextRace(calendar, singapore.start.plusSeconds(4 * 3600))
        for (race in listOf(singapore, next)) {
            RaceRepository.save(context, race)
            val view = render(340, 185)
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            // Preserve real Android renders in the existing Actions log without
            // changing the user's APK-only artifact workflow.
            Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP).chunked(10000)
                .forEachIndexed { i, chunk -> println("WIDGET_PREVIEW_${race.circuitId}_$i $chunk") }
        }
    }
}
