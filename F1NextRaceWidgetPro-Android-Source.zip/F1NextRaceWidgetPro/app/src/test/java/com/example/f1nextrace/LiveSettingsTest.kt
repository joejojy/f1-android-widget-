package com.example.f1nextrace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlarmManager

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],qualifiers="xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class LiveSettingsTest {
    private fun descendants(view: View): List<View> = listOf(view) +
        if(view is ViewGroup) (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()

    @Test fun setupOpensPermissionScreenOnlyOnTapAndRemembersOptIn() {
        val context: Context=RuntimeEnvironment.getApplication()
        context.getSharedPreferences("f1_auto_live",Context.MODE_PRIVATE).edit().clear().commit()
        ShadowAlarmManager.setCanScheduleExactAlarms(false)
        val controller=Robolectric.buildActivity(LiveSettingsActivity::class.java).setup().visible()
        val activity=controller.get()
        assertNull(shadowOf(activity).nextStartedActivity)
        val root=activity.findViewById<View>(android.R.id.content)
        val enable=descendants(root).filterIsInstance<Button>().first { it.text == "Enable automatic live" }
        enable.performClick()
        assertTrue(AutoLiveScheduler.enabled(context))
        val request=shadowOf(activity).nextStartedActivity
        assertEquals(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,request.action)
        assertEquals("package:${context.packageName}",request.dataString)
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        controller.pause().resume()
        assertFalse(enable.isEnabled)
        assertTrue(AutoLiveScheduler.enabled(context))
        val density=context.resources.displayMetrics.density
        val w=(360*density).toInt();val h=(760*density).toInt()
        root.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY))
        root.layout(0,0,w,h)
        val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        root.draw(Canvas(bitmap))
        val output=java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG,100,output)
        java.util.Base64.getEncoder().encodeToString(output.toByteArray()).chunked(10000)
            .forEachIndexed { i, data -> println("SETTINGS_PREVIEW_${i} $data") }
        descendants(root).filterIsInstance<Button>().first { it.text == "Turn off automatic starts" }.performClick()
        assertFalse(AutoLiveScheduler.enabled(context))
        controller.pause().stop().destroy()
    }
}
