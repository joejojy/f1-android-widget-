package com.example.f1nextrace

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Base64
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.StackView
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.time.Instant
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],qualifiers="xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class HistoryTest {
    private val c: Context get()=RuntimeEnvironment.getApplication()
    private val monday=Instant.parse("2026-10-12T06:00:00Z")
    @Before fun reset() { for(name in listOf("f1_history","f1_live","f1_race_cache")) c.getSharedPreferences(name,0).edit().clear().commit() }
    private fun session(key: Long,name: String,end: String)=JSONObject().put("session_key",key)
        .put("session_name",name).put("location","Singapore Grand Prix").put("date_start",end).put("date_end",end)
    private fun row(n: Int)=JSONObject().put("session_key",7).put("driver_number",n).put("position",n)
        .put("duration",90.123+n).put("gap_to_leader",n*2.25).put("name",listOf("VERSTAPPEN","LECLERC","HAMILTON","ANTONELLI","NORRIS")[n-1])
    private fun finished()=session(7,"Race","2026-10-11T14:00:00Z")
        .put("rows",JSONArray((1..5).map { row(it) })).put("fetched",monday.toEpochMilli())
    @Test fun newestCompletedSelectionHandlesFridayMondayFutureAndCancelled() {
        val fp=session(1,"Practice 1","2026-10-09T09:00:00Z")
        val sq=session(2,"Sprint Qualifying","2026-10-09T13:00:00Z")
        val race=finished()
        val future=session(8,"Race","2026-10-18T14:00:00Z")
        val cancelled=session(9,"Practice 3","2026-10-12T01:00:00Z").put("is_cancelled",true)
        val all=JSONArray(listOf(future,race,sq,fp,cancelled))
        assertEquals(listOf(7L,2L,1L),SessionHistory.candidates(all,monday).map { it.getLong("session_key") })
        assertEquals(1L,SessionHistory.candidates(all,Instant.parse("2026-10-09T10:00:00Z")).first().getLong("session_key"))
        assertEquals(2L,SessionHistory.candidates(all,Instant.parse("2026-10-09T14:00:00Z")).first().getLong("session_key"))
    }
    @Test fun publishedClassificationIsNotResortedByQualifyingTimes() {
        val first=row(1).put("duration",JSONArray("[92.0,91.0,90.0]"))
        val second=row(2).put("duration",JSONArray("[89.0,90.0,null]"))
        val rows=SessionHistory.results(JSONArray(listOf(second,first,row(3).put("session_key",999))),7)
        assertEquals(listOf(1,2),rows.map { it.getInt("position") })
        assertEquals("Q3 1:30.000",SessionHistory.timing(rows[0],false))
        assertEquals("Q2 1:30.000",SessionHistory.timing(rows[1],false))
        assertEquals("1:00.000",SessionHistory.lap(59.9999))
        assertEquals("—",SessionHistory.lap(Double.NaN))
    }
    @Test fun raceGapsAndStatusesRemainAccurate() {
        assertEquals("WINNER",SessionHistory.timing(row(1),true))
        assertEquals("+4.500",SessionHistory.timing(row(2),true))
        assertEquals("+1 LAP",SessionHistory.timing(row(2).put("gap_to_leader","+1 LAP"),true))
        assertEquals("DSQ",SessionHistory.timing(row(1).put("dsq",true),true))
        assertEquals("DNS",SessionHistory.timing(row(2).put("dns",true),true))
        assertEquals("DNF",SessionHistory.timing(row(3).put("dnf",true),true))
    }
    @Test fun fetchWorksWithoutLiveCacheCachesOfflineAndPreservesRowsOnEmptyResponse() {
        val meta=session(7,"Race","2026-10-11T14:00:00Z")
        var calls=0
        val getter: (String,Map<String,String>)->JSONArray={ path,_ ->
            calls++
            when(path) {
                "sessions" -> JSONArray(listOf(meta))
                "session_result" -> JSONArray((1..5).map { row(it) })
                else -> JSONArray((1..5).map { JSONObject().put("driver_number",it).put("last_name","DRIVER $it") })
            }
        }
        SessionHistory.refresh(c,monday,getter)
        assertEquals(3,calls)
        assertNull(LiveCache.read(c))
        assertEquals("DRIVER 1",SessionHistory.read(c).first().getJSONArray("rows").getJSONObject(0).getString("name"))
        SessionHistory.refresh(c,monday.plusSeconds(30),getter)
        assertEquals(3,calls)
        SessionHistory.refresh(c,monday.plusSeconds(7200)) { path,_ -> if(path=="sessions") JSONArray(listOf(meta)) else JSONArray() }
        assertEquals(5,SessionHistory.read(c).first().getJSONArray("rows").length())
        runCatching { SessionHistory.refresh(c,monday.plusSeconds(14400)) { _,_->error("Offline") } }
        assertEquals(5,SessionHistory.read(c).first().getJSONArray("rows").length())
    }
    @Test fun publicationDelayCreatesPendingCardNotLiveClassification() {
        SessionHistory.refresh(c,monday) { path,_ -> if(path=="sessions") JSONArray(listOf(session(7,"Race","2026-10-11T14:00:00Z"))) else JSONArray() }
        val v=WidgetDeck.resultCard(c,SessionHistory.read(c).first()).apply(c,FrameLayout(c))
        assertEquals("PENDING",v.findViewById<TextView>(R.id.result_status).text)
        assertEquals(View.VISIBLE,v.findViewById<View>(R.id.result_empty).visibility)
        assertEquals(View.GONE,v.findViewById<View>(R.id.result_1).visibility)
    }
    @Test fun tappingAnUnloadedSessionPrioritisesItWithoutRepeatedNetworkSpam() {
        val sessions=(1L..6L).map { session(it,"Practice 1","2026-10-09T09:00:00Z") }
        SessionHistory.refresh(c,monday) { path,_ -> if(path=="sessions") JSONArray(sessions) else JSONArray() }
        SessionHistory.request(c,6)
        val queried=mutableListOf<Long>()
        val getter: (String,Map<String,String>)->JSONArray={ path,args ->
            if(path=="sessions") JSONArray(sessions) else {
                if(path=="session_result") queried.add(args.getValue("session_key").toLong())
                JSONArray()
            }
        }
        SessionHistory.refresh(c,monday.plusSeconds(1),getter)
        assertEquals(6L,queried.first())
        val count=queried.size
        SessionHistory.refresh(c,monday.plusSeconds(2),getter)
        assertEquals(count,queried.size)
    }
    private fun layout(v: View,w: Int,h: Int) {
        val d=c.resources.displayMetrics.density
        v.measure(View.MeasureSpec.makeMeasureSpec((w*d).toInt(),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec((h*d).toInt(),View.MeasureSpec.EXACTLY))
        v.layout(0,0,v.measuredWidth,v.measuredHeight)
    }
    @Test fun resultRowsFitAndCompactShowsPodium() {
        for(w in listOf(250,320,340)) {
            val v=WidgetDeck.resultCard(c,finished(),w<300).apply(c,FrameLayout(c))
            layout(v,w,172)
            assertEquals(if(w<300) View.GONE else View.VISIBLE,v.findViewById<View>(R.id.result_5).visibility)
            for(id in listOf(R.id.result_1,R.id.result_2,R.id.result_3,R.id.result_footer)) {
                val t=v.findViewById<TextView>(id)
                assertTrue("height at $w",t.layout.height<=t.height)
                assertTrue("width at $w",t.layout.getLineWidth(0)<=t.width)
            }
            if(w==340) {
                val b=Bitmap.createBitmap(v.width,v.height,Bitmap.Config.ARGB_8888);v.draw(Canvas(b))
                val out=ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out)
                Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP).chunked(10000).forEachIndexed { i,s -> println("HISTORY_PREVIEW_${i} $s") }
            }
        }
    }
    @Test fun responsiveDraftScreenshots() {
        java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("Asia/Kolkata"))
        try {
            for((w,h) in listOf(200 to 150,250 to 170,340 to 220,400 to 300)) {
                val v=WidgetDeck.resultCard(c,finished(),h<210).apply(c,FrameLayout(c))
                layout(v,w,h)
                for(id in listOf(R.id.result_heading,R.id.result_title,R.id.result_date,R.id.result_1,R.id.result_2,R.id.result_3,R.id.result_4,R.id.result_5,R.id.result_footer)) {
                    val t=v.findViewById<TextView>(id)
                    if(t.visibility!=View.VISIBLE) continue
                    assertTrue("height $id at $w x $h",t.layout.height<=t.height)
                    assertTrue("width $id at $w x $h",t.layout.getLineWidth(0)<=t.width)
                }
                val b=Bitmap.createBitmap(v.width,v.height,Bitmap.Config.ARGB_8888)
                v.draw(Canvas(b))
                val file=java.io.File("build/previews/results-${w}x${h}.png")
                file.parentFile.mkdirs()
                file.outputStream().use { b.compress(Bitmap.CompressFormat.PNG,100,it) }
            }
        } finally { java.util.TimeZone.setDefault(null) }
    }
    @Test fun factoryUsesStableSessionIdsAndRootProvidesNativeSwipeStack() {
        SessionHistory.save(c,listOf(finished()))
        val factory=HistoryViewsService.Factory(c,42);factory.onCreate()
        assertEquals(2,factory.getCount());assertEquals(0L,factory.getItemId(0));assertEquals(7L,factory.getItemId(1))
        SessionHistory.save(c,listOf(session(8,"Practice 1","2026-10-16T12:00:00Z"),finished()))
        factory.onDataSetChanged()
        assertEquals(7L,factory.getItemId(2))
        val root=WidgetDeck.root(c,42).apply(c,FrameLayout(c))
        assertTrue(root.findViewById<View>(R.id.cards) is StackView)
        assertEquals(1,(root as android.view.ViewGroup).childCount)
        assertEquals("PUBLISHED",factory.getViewAt(2).apply(c,FrameLayout(c)).findViewById<TextView>(R.id.result_status).text)
    }
    @Test fun homeCardCountdownStillFitsWithoutNavigation() {
        RaceRepository.save(c,RaceInfo("Singapore Grand Prix","Marina Bay","Singapore",monday.plusSeconds(9720),"marina_bay"))
        for(w in listOf(250,340)) {
            val v=NextRaceWidgetProvider.renderWidget(c,nowMillis=monday.toEpochMilli(),collection=true).apply(c,FrameLayout(c))
            layout(v,w,172)
            assertEquals("START IN  •  2h 42m",v.findViewById<TextView>(R.id.countdown).text)
            val footer=v.findViewById<TextView>(R.id.footer)
            assertTrue(footer.layout.height<=footer.height)
        }
    }
}

