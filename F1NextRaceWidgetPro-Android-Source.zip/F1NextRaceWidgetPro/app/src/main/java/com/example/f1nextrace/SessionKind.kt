package com.example.f1nextrace

enum class SessionKind(val label: String, val racing: Boolean, val windowHours: Long) {
    PRACTICE_1("PRACTICE 1",false,2), PRACTICE_2("PRACTICE 2",false,2), PRACTICE_3("PRACTICE 3",false,2),
    QUALIFYING("QUALIFYING",false,3), SPRINT_QUALIFYING("SPRINT QUALIFYING",false,2),
    SPRINT("SPRINT",true,2), RACE("RACE",true,4);

    val qualifying get() = this == QUALIFYING || this == SPRINT_QUALIFYING
    fun matches(type: String, name: String): Boolean {
        val normalized = name.lowercase(java.util.Locale.ENGLISH).replace(" ", "")
        return when (this) {
            RACE -> type == "Race" && normalized in listOf("race", "")
            SPRINT -> type == "Race" && normalized == "sprint"
            QUALIFYING -> type == "Qualifying" && normalized == "qualifying"
            SPRINT_QUALIFYING -> type == "Qualifying" && normalized in listOf("sprintqualifying","sprintshootout")
            else -> type == "Practice" && normalized == "practice${ordinal+1}"
        }
    }
}
