package com.example.f1nextrace

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** One-time, visible opt-in for race alarms; no background settings launches. */
class LiveSettingsActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var enable: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (24 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
            setBackgroundColor(Color.rgb(17,17,20))
        }
        fun text(value: String, size: Float): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE)
            setPadding(0,16,0,16); column.addView(this)
        }
        text("Automatic session timing", 24f)
        text("Start live timing at each scheduled session start, even when the app is closed. The widget shows the top five once current session data arrives.", 16f)
        text("Android needs Alarms & reminders access to start at session start. Enable this once for future sessions. Live timing uses the internet and keeps a foreground task running during the session.", 16f)
        status = text("",16f)
        enable = Button(this).apply {
            backgroundTintList = ColorStateList.valueOf(Color.rgb(230,50,50))
            setTextColor(Color.WHITE)
            setOnClickListener {
                AutoLiveScheduler.setEnabled(this@LiveSettingsActivity, true)
                if (!AutoLiveScheduler.permitted(this@LiveSettingsActivity) && Build.VERSION.SDK_INT >= 31) {
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:$packageName")))
                    } catch (_: android.content.ActivityNotFoundException) {
                        status.text = "Open Android Settings → Apps → Special app access → Alarms & reminders, and allow F1 Next Race."
                    }
                } else refresh()
            }
            column.addView(this)
        }
        Button(this).apply {
            text = "Turn off automatic starts"
            setOnClickListener { AutoLiveScheduler.setEnabled(this@LiveSettingsActivity,false); refresh() }
            column.addView(this)
        }
        if (Build.VERSION.SDK_INT >= 33) Button(this).apply {
            text = "Allow live notification"
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1) }
            column.addView(this)
        }
        text("STOP LIVE on the widget stops updates for this session. Future sessions still start automatically. Turning off automatic starts affects future starts; use STOP LIVE to end a running connection.",14f)
        text("Keep a widget on your home screen. After a restart the app restores its session alarm. If the phone is off, the app is force-stopped, or Android removes its permissions, automatic starts may be unavailable.",14f)
        setContentView(ScrollView(this).apply { addView(column); setBackgroundColor(Color.rgb(17,17,20)) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val enabled = AutoLiveScheduler.enabled(this)
        val permitted = AutoLiveScheduler.permitted(this)
        status.text = when {
            !enabled -> "Automatic starts are off."
            !permitted -> "Allow Alarms & reminders to finish setup."
            !AutoLiveScheduler.hasWidgets(this) -> "Enabled. Add the F1 widget to your home screen."
            else -> "Enabled for future sessions. Practice, qualifying, sprints and races."
        }
        enable.text = if (enabled && permitted) "Automatic starts enabled" else "Enable automatic live"
        enable.isEnabled = !enabled || !permitted
        AutoLiveScheduler.schedule(this)
        NextRaceWidgetProvider.updateAll(this)
        if (AutoLiveScheduler.hasWidgets(this)) NextRaceWidgetProvider.scheduleRefresh(this)
    }
}
