package com.example.f1nextrace

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class WidgetActionActivity: Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        when(intent.getStringExtra("widgetAction")) {
            "details" -> { details(intent.getLongExtra("sessionKey",0)); return }
            "settings" -> startActivity(Intent(this,LiveSettingsActivity::class.java))
            "calendar" -> runCatching { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.formula1.com/en/racing/${java.time.Year.now().value}"))) }
            "start" -> runCatching { startForegroundService(Intent(this,LiveRaceService::class.java)) }
            "stop" -> { AutoLiveScheduler.skipCurrentRace(this); stopService(Intent(this,LiveRaceService::class.java)); NextRaceWidgetProvider.updateAll(this) }
            "refresh" -> NextRaceWidgetProvider.updateAll(this)
            "history" -> HistoryWorker.request(this)
        }
        finish()
    }
    private fun details(key: Long) {
        val session=SessionHistory.read(this).firstOrNull { it.optLong("session_key")==key }
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(32,48,32,32);setBackgroundColor(Color.rgb(17,17,21)) }
        fun text(value: String,size: Float=17f,color: Int=Color.WHITE) {
            root.addView(TextView(this).apply { text=value;textSize=size;setTextColor(color);setPadding(0,12,0,12) })
        }
        val home=TextView(this).apply { text="‹ BACK";textSize=18f;setTextColor(Color.rgb(255,81,76));setPadding(0,16,0,24);setOnClickListener { finish() } }
        root.addView(home)
        text(session?.optString("location") ?: "Session results",26f)
        text(session?.optString("session_name") ?: "No saved results")
        text(session?.optString("date_start") ?: "",14f,Color.LTGRAY)
        text("Published classification • saved copy",14f,Color.LTGRAY)
        val kind=SessionHistory.kind(session?.optString("session_name") ?: "")
        val rows=session?.optJSONArray("rows")
        if(rows!=null) for(row in SessionHistory.objects(rows)) {
            text(SessionHistory.line(row,kind?.racing==true))
            val parts=row.optJSONArray("duration")
            if(parts!=null) text((0 until parts.length()).joinToString("   ") { "Q${it+1} ${SessionHistory.lap(parts.optDouble(it,0.0))}" },13f,Color.LTGRAY)
            text("Laps: ${row.optInt("number_of_laps")}",13f,Color.LTGRAY)
        }
        text("Source: OpenF1 • Later penalties may change published results.",13f,Color.LTGRAY)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
