package com.example.f1nextrace

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class RaceRefreshWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            RaceRepository.fetchAndCache(applicationContext)
            refreshWidgets(applicationContext)
            Result.success()
        } catch (error: Exception) {
            android.util.Log.w("F1Schedule","Schedule refresh failed; retaining saved data",error)
            // Retry transient network/server errors, keeping the last successful cached race visible.
            if (runAttemptCount < 3) Result.retry() else {
                refreshWidgets(applicationContext)
                Result.failure()
            }
        }
    }

    private fun refreshWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(
            ComponentName(context, NextRaceWidgetProvider::class.java)
        )
        ids.forEach { NextRaceWidgetProvider.updateWidget(context, manager, it) }
    }
}
