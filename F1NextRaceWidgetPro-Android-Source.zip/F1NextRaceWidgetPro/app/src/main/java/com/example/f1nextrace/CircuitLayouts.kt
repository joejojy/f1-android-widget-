package com.example.f1nextrace

// Bundled geographic outlines: bacinger/f1-circuits (MIT).
// See assets/circuit-layouts-LICENSE.txt for attribution and source revision.
object CircuitLayouts {
    private val resources = mapOf(
        "albert_park" to R.drawable.track_albert_park,
        "bahrain" to R.drawable.track_bahrain,
        "shanghai" to R.drawable.track_shanghai,
        "catalunya" to R.drawable.track_catalunya,
        "monaco" to R.drawable.track_monaco,
        "villeneuve" to R.drawable.track_villeneuve,
        "red_bull_ring" to R.drawable.track_red_bull_ring,
        "silverstone" to R.drawable.track_silverstone,
        "hungaroring" to R.drawable.track_hungaroring,
        "spa" to R.drawable.track_spa,
        "monza" to R.drawable.track_monza,
        "marina_bay" to R.drawable.track_marina_bay,
        "suzuka" to R.drawable.track_suzuka,
        "americas" to R.drawable.track_americas,
        "rodriguez" to R.drawable.track_rodriguez,
        "interlagos" to R.drawable.track_interlagos,
        "yas_marina" to R.drawable.track_yas_marina,
        "imola" to R.drawable.track_imola,
        "sepang" to R.drawable.track_sepang,
        "zandvoort" to R.drawable.track_zandvoort,
        "jeddah" to R.drawable.track_jeddah,
        "miami" to R.drawable.track_miami,
        "losail" to R.drawable.track_losail,
        "madring" to R.drawable.track_madring,
        "baku" to R.drawable.track_baku,
        "vegas" to R.drawable.track_vegas,
    )

    fun resourceFor(circuitId: String): Int = resources[circuitId] ?: 0
}
