package com.example.f1nextrace

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.OffsetDateTime

data class RaceInfo(
    val name: String,
    val locality: String,
    val country: String,
    val start: Instant
)

object RaceRepository {
    private const val PREFS = "f1_race_cache"
    private const val KEY_NAME = "name"
    private const val KEY_LOCALITY = "locality"
    private const val KEY_COUNTRY = "country"
    private const val KEY_START = "start"
    private const val KEY_UPDATED = "updated"

    fun fetchAndCache(context: Context): RaceInfo {
        val connection = (URL("https://api.jolpi.ca/ergast/f1/current/races/?format=json")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "F1NextRaceWidget/2.0")
        }

        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Schedule service returned ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val races = root.getJSONObject("MRData")
                .getJSONObject("RaceTable")
                .getJSONArray("Races")
            val now = Instant.now()
            var next: RaceInfo? = null

            for (i in 0 until races.length()) {
                val item = races.getJSONObject(i)
                val date = item.optString("date")
                val time = item.optString("time")
                if (date.isBlank()) continue

                // Jolpica/Ergast race times are UTC. If the API omits time, skip rather than invent one.
                if (time.isBlank()) continue
                val timestamp = try {
                    OffsetDateTime.parse("${date}T${time}").toInstant()
                } catch (_: Exception) {
                    continue
                }
                if (timestamp.isAfter(now)) {
                    val circuit = item.optJSONObject("Circuit")
                    val location = circuit?.optJSONObject("Location")
                    next = RaceInfo(
                        name = item.optString("raceName", "Formula 1 Grand Prix"),
                        locality = location?.optString("locality", "") ?: "",
                        country = location?.optString("country", "") ?: "",
                        start = timestamp
                    )
                    break
                }
            }

            val result = next ?: throw IllegalStateException("No future race found in the current schedule")
            save(context, result)
            return result
        } finally {
            connection.disconnect()
        }
    }

    fun cached(context: Context): RaceInfo? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val start = p.getString(KEY_START, null) ?: return null
        return try {
            RaceInfo(
                name = p.getString(KEY_NAME, "Formula 1 Grand Prix") ?: "Formula 1 Grand Prix",
                locality = p.getString(KEY_LOCALITY, "") ?: "",
                country = p.getString(KEY_COUNTRY, "") ?: "",
                start = Instant.parse(start)
            )
        } catch (_: Exception) { null }
    }

    fun lastUpdated(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_UPDATED, 0L)

    private fun save(context: Context, race: RaceInfo) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_NAME, race.name)
            .putString(KEY_LOCALITY, race.locality)
            .putString(KEY_COUNTRY, race.country)
            .putString(KEY_START, race.start.toString())
            .putLong(KEY_UPDATED, System.currentTimeMillis())
            .apply()
    }
}
