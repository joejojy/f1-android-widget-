package com.example.f1nextrace

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.OffsetDateTime

data class RaceInfo(
    val name: String,
    val locality: String,
    val country: String,
    val start: Instant,
    val circuitId: String = "",
    val circuitName: String = "",
    val kind: SessionKind = SessionKind.RACE
) {
    val sessionId get() = "$circuitId|${kind.name}|$start"
    val windowMillis get() = kind.windowHours * 3_600_000L
}

object RaceRepository {
    private const val PREFS = "f1_race_cache"
    private const val KEY_NAME = "name"
    private const val KEY_LOCALITY = "locality"
    private const val KEY_COUNTRY = "country"
    private const val KEY_START = "start"
    private const val KEY_CIRCUIT_ID = "circuit_id"
    private const val KEY_CIRCUIT_NAME = "circuit_name"
    private const val KEY_UPDATED = "updated"

    fun fetchAndCache(context: Context): RaceInfo {
        val connection = (URL("https://api.jolpi.ca/ergast/f1/current/races/?format=json")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "F1NextRaceWidget/2.0")
        }

        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Schedule service returned ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val result = selectSession(parseSessions(body), Instant.now(), completed(context))
                ?: throw IllegalStateException("No upcoming session")
            context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString("calendar",body).apply()
            save(context, result)
            return result
        } finally {
            connection.disconnect()
        }
    }

    internal fun parseNextRace(body: String, now: Instant = Instant.now()): RaceInfo {
        return selectSession(parseSessions(body),now) ?: throw IllegalStateException("No upcoming session")
    }

    internal fun parseSessions(body: String): List<RaceInfo> {
        val root = JSONObject(body)
        val races = root.getJSONObject("MRData")
            .getJSONObject("RaceTable")
            .getJSONArray("Races")
        val sessions = mutableListOf<RaceInfo>()

        for (i in 0 until races.length()) {
            val item = races.getJSONObject(i)
            val entries = listOf("FirstPractice" to SessionKind.PRACTICE_1,
                "SecondPractice" to SessionKind.PRACTICE_2, "ThirdPractice" to SessionKind.PRACTICE_3,
                "Qualifying" to SessionKind.QUALIFYING, "SprintQualifying" to SessionKind.SPRINT_QUALIFYING,
                "SprintShootout" to SessionKind.SPRINT_QUALIFYING, "Sprint" to SessionKind.SPRINT,
                "" to SessionKind.RACE)
            for ((key,kind) in entries) {
            val event = if (key.isEmpty()) item else item.optJSONObject(key) ?: continue
            val date = event.optString("date")
            val time = event.optString("time")
            if (date.isBlank()) continue

            // Jolpica/Ergast race times are UTC. If the API omits time, skip rather than invent one.
            if (time.isBlank()) continue
            val timestamp = try {
                OffsetDateTime.parse("${date}T${time}").toInstant()
            } catch (_: Exception) {
                continue
            }
            // Keep the current race visible while live timing can be running.
            run {
                val circuit = item.optJSONObject("Circuit")
                val location = circuit?.optJSONObject("Location")
                sessions.add(RaceInfo(
                    name = item.optString("raceName", "Formula 1 Grand Prix"),
                    locality = location?.optString("locality", "") ?: "",
                    country = location?.optString("country", "") ?: "",
                    start = timestamp,
                    circuitId = circuit?.optString("circuitId", "") ?: "",
                    circuitName = circuit?.optString("circuitName", "") ?: "",
                    kind = kind
                ))
            }
            }
        }

        return sessions.distinctBy { it.sessionId }.sortedBy { it.start }
    }

    internal fun selectSession(sessions: List<RaceInfo>, now: Instant, completed: Set<String> = emptySet()): RaceInfo? {
        val started = sessions.lastOrNull { !it.start.isAfter(now) }
        if (started != null && started.sessionId !in completed &&
            now.toEpochMilli() < started.start.toEpochMilli() + started.windowMillis) return started
        return sessions.firstOrNull { it.start.isAfter(now) && it.sessionId !in completed }
    }

    private fun completed(context: Context) = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        .getStringSet("completed",emptySet())!!.toSet()

    fun complete(context: Context, session: RaceInfo) {
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putStringSet("completed", completed(context) + session.sessionId).apply()
    }

    private fun calendar(context: Context): List<RaceInfo>? = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        .getString("calendar",null)?.let { runCatching { parseSessions(it) }.getOrNull() }

    fun nextForAuto(context: Context, now: Instant, handled: Set<String>): RaceInfo? {
        val sessions = calendar(context) ?: listOfNotNull(cachedSingle(context))
        val current = selectSession(sessions,now,completed(context))
        if (current != null && current.sessionId !in handled) return current
        return sessions.firstOrNull { it.start.isAfter(now) && it.sessionId !in handled && it.sessionId !in completed(context) }
    }

    fun cached(context: Context, now: Instant = Instant.now()): RaceInfo? {
        val sessions = calendar(context)
        return if (sessions != null) selectSession(sessions,now,completed(context)) else cachedSingle(context)
    }

    private fun cachedSingle(context: Context): RaceInfo? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val start = p.getString(KEY_START, null) ?: return null
        return try {
            RaceInfo(
                name = p.getString(KEY_NAME, "Formula 1 Grand Prix") ?: "Formula 1 Grand Prix",
                locality = p.getString(KEY_LOCALITY, "") ?: "",
                country = p.getString(KEY_COUNTRY, "") ?: "",
                start = Instant.parse(start),
                circuitId = p.getString(KEY_CIRCUIT_ID, "") ?: "",
                circuitName = p.getString(KEY_CIRCUIT_NAME, "") ?: "",
                kind = runCatching { SessionKind.valueOf(p.getString("session_kind","RACE")!!) }.getOrDefault(SessionKind.RACE)
            )
        } catch (_: Exception) { null }
    }

    fun lastUpdated(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_UPDATED, 0L)

    internal fun save(context: Context, race: RaceInfo) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_NAME, race.name)
            .putString(KEY_LOCALITY, race.locality)
            .putString(KEY_COUNTRY, race.country)
            .putString(KEY_START, race.start.toString())
            .putString(KEY_CIRCUIT_ID, race.circuitId)
            .putString(KEY_CIRCUIT_NAME, race.circuitName)
            .putString("session_kind",race.kind.name)
            .putLong(KEY_UPDATED, System.currentTimeMillis())
            .apply()
    }
}
