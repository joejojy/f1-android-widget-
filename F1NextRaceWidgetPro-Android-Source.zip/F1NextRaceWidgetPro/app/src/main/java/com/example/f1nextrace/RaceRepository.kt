package com.example.f1nextrace

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.OffsetDateTime

data class RaceInfo(
    val name: String,
    val locality: String,
    val country: String,
    val start: Instant,
    val circuitId: String = "",
    val circuitName: String = ""
)

object RaceRepository {
    private const val PREFS = "f1_race_cache"
    private const val KEY_NAME = "name"
    private const val KEY_LOCALITY = "locality"
    private const val KEY_COUNTRY = "country"
    private const val KEY_START = "start"
    private const val KEY_CIRCUIT_ID = "circuit_id"
    private const val KEY_CIRCUIT_NAME = "circuit_name"
    private const val KEY_UPDATED = "updated"

    fun fetchAndCache(context: Context): RaceInfo {
        val connection = (URL("https://api.jolpi.ca/ergast/f1/current/races/?format=json")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "F1NextRaceWidget/2.0")
        }

        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Schedule service returned ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val result = parseNextRace(body)
            save(context, result)
            return result
        } finally {
            connection.disconnect()
        }
    }

    internal fun parseNextRace(body: String, now: Instant = Instant.now()): RaceInfo {
        val root = JSONObject(body)
        val races = root.getJSONObject("MRData")
            .getJSONObject("RaceTable")
            .getJSONArray("Races")
        var next: RaceInfo? = null

        for (i in 0 until races.length()) {
            val item = races.getJSONObject(i)
            val date = item.optString("date")
            val time = item.optString("time")
            if (date.isBlank()) continue

            // Jolpica/Ergast race times are UTC. If the API omits time, skip rather than invent one.
            if (time.isBlank()) continue
            val timestamp = try {
                OffsetDateTime.parse("${date}T${time}").toInstant()
            } catch (_: Exception) {
                continue
            }
            if (timestamp.isAfter(now)) {
                val circuit = item.optJSONObject("Circuit")
                val location = circuit?.optJSONObject("Location")
                next = RaceInfo(
                    name = item.optString("raceName", "Formula 1 Grand Prix"),
                    locality = location?.optString("locality", "") ?: "",
                    country = location?.optString("country", "") ?: "",
                    start = timestamp,
                    circuitId = circuit?.optString("circuitId", "") ?: "",
                    circuitName = circuit?.optString("circuitName", "") ?: ""
                )
                break
            }
        }

        return next ?: throw IllegalStateException("No future race found in the current schedule")
    }

    fun cached(context: Context): RaceInfo? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val start = p.getString(KEY_START, null) ?: return null
        return try {
            RaceInfo(
                name = p.getString(KEY_NAME, "Formula 1 Grand Prix") ?: "Formula 1 Grand Prix",
                locality = p.getString(KEY_LOCALITY, "") ?: "",
                country = p.getString(KEY_COUNTRY, "") ?: "",
                start = Instant.parse(start),
                circuitId = p.getString(KEY_CIRCUIT_ID, "") ?: "",
                circuitName = p.getString(KEY_CIRCUIT_NAME, "") ?: ""
            )
        } catch (_: Exception) { null }
    }

    fun lastUpdated(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_UPDATED, 0L)

    internal fun save(context: Context, race: RaceInfo) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_NAME, race.name)
            .putString(KEY_LOCALITY, race.locality)
            .putString(KEY_COUNTRY, race.country)
            .putString(KEY_START, race.start.toString())
            .putString(KEY_CIRCUIT_ID, race.circuitId)
            .putString(KEY_CIRCUIT_NAME, race.circuitName)
            .putLong(KEY_UPDATED, System.currentTimeMillis())
            .apply()
    }
}
