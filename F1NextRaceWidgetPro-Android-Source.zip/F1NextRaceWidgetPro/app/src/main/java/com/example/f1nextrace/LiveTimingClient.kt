package com.example.f1nextrace

import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Public, unauthenticated timing transport used by FastF1. No account or tokens. */
internal class LiveTimingClient(
    private val onData: (String, JSONObject, String?) -> Unit,
    private val onLost: () -> Unit,
    private val endpoint: String = "https://livetiming.formula1.com/signalrcore"
) {
    private val executor = Executors.newSingleThreadExecutor()
    private val cookies = mutableListOf<Cookie>()
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS).callTimeout(20, TimeUnit.SECONDS)
        .cookieJar(object : CookieJar {
            override fun saveFromResponse(url: HttpUrl, incoming: List<Cookie>) = synchronized(cookies) {
                incoming.forEach { cookie ->
                    cookies.removeAll { it.name == cookie.name && it.domain == cookie.domain && it.path == cookie.path }
                    cookies.add(cookie)
                }
            }
            override fun loadForRequest(url: HttpUrl): List<Cookie> = synchronized(cookies) {
                cookies.filter { it.matches(url) && it.expiresAt > System.currentTimeMillis() }
            }
        }).build()
    @Volatile private var stopped = false
    @Volatile private var socket: WebSocket? = null

    fun connect() {
        executor.execute {
            try {
                // Establish the load-balancer affinity cookie, as FastF1 does.
                client.newCall(Request.Builder().url("$endpoint/negotiate").method("OPTIONS", null).build())
                    .execute().use { if (!it.isSuccessful) error("Timing unavailable") }
                val negotiation = client.newCall(Request.Builder().url("$endpoint/negotiate?negotiateVersion=1")
                    .post(ByteArray(0).toRequestBody()).build()).execute().use {
                    if (!it.isSuccessful) error("Timing unavailable")
                    JSONObject(it.body!!.string())
                }
                val token = negotiation.optString("connectionToken").ifBlank { negotiation.getString("connectionId") }
                val url = Request.Builder().url(endpoint).build().url.newBuilder().addQueryParameter("id", token).build()
                if (stopped) return@execute
                socket = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
                    private var handshake = false
                    private var pending = ""
                    override fun onOpen(ws: WebSocket, response: Response) {
                        if (stopped) { ws.cancel(); return }
                        ws.send("{\"protocol\":\"json\",\"version\":1}\u001e")
                    }
                    override fun onMessage(ws: WebSocket, text: String) {
                        if (stopped) return
                        try {
                            pending += text
                            if (pending.length > 2_000_000) error("Oversized timing message")
                            while ('\u001e' in pending) {
                                val split = pending.indexOf('\u001e')
                                val frame = JSONObject(pending.substring(0, split))
                                pending = pending.substring(split + 1)
                                if (!handshake) {
                                    if (frame.has("error")) error("Handshake rejected")
                                    handshake = true
                                    ws.send(JSONObject().put("type", 1).put("invocationId", "1")
                                        .put("target", "Subscribe").put("arguments", JSONArray().put(JSONArray(listOf(
                                            "Heartbeat", "DriverList", "SessionInfo", "SessionStatus", "TimingData", "LapCount"
                                        )))).toString() + '\u001e')
                                } else when (frame.optInt("type")) {
                                    1 -> if (frame.optString("target").equals("feed", true)) {
                                        val args = frame.getJSONArray("arguments")
                                        val data = args.get(1)
                                        onData(args.getString(0), if (data is JSONObject) data else JSONObject(data.toString()),
                                            args.optString(2).takeIf { it.isNotBlank() })
                                    }
                                    3 -> {
                                        if (frame.has("error")) error("Subscription rejected")
                                        val result = frame.optJSONObject("result") ?: continue
                                        result.keys().forEach { topic ->
                                            result.optJSONObject(topic)?.let { onData(topic, it, null) }
                                        }
                                    }
                                    7 -> error("Timing stream closed")
                                }
                            }
                        } catch (_: Exception) { ws.cancel(); lost() }
                    }
                    override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) = lost()
                    override fun onClosed(ws: WebSocket, code: Int, reason: String) = lost()
                    override fun onClosing(ws: WebSocket, code: Int, reason: String) { ws.close(code, null); lost() }
                })
            } catch (_: Exception) { lost() }
        }
    }

    fun ping() { socket?.send("{\"type\":6}\u001e") }
    private fun lost() { if (!stopped) onLost() }
    fun close() {
        stopped = true
        socket?.cancel()
        client.dispatcher.cancelAll()
        executor.shutdownNow()
        client.connectionPool.evictAll()
        client.dispatcher.executorService.shutdown()
    }
}
