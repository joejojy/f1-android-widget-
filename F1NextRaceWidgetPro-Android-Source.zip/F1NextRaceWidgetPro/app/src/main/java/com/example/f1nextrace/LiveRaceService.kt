package com.example.f1nextrace

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import org.json.JSONObject

internal object LiveCache {
    fun read(context: Context): JSONObject? = runCatching {
        JSONObject(context.getSharedPreferences("f1_live", Context.MODE_PRIVATE).getString("state", "")!!)
    }.getOrNull()
    fun save(context: Context, value: JSONObject) {
        context.getSharedPreferences("f1_live", Context.MODE_PRIVATE).edit().putString("state", value.toString()).apply()
    }
    fun active(value: JSONObject?, now: Long, elapsed: Long): Boolean = value != null &&
        value.optBoolean("running") && now - value.optLong("tickWall") in 0L..30_000L &&
        elapsed - value.optLong("tickElapsed") in 0L..30_000L
}

class LiveRaceService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var client: LiveTimingClient? = null
    private var state = LiveTimingState()
    private var race: RaceInfo? = null
    private var started = 0L
    private var lastMessage = 0L
    private var generation = 0
    private var retryDelay = 5_000L
    private var retryAt = 0L
    private var stopping = false

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("live_race", "Live race timing", NotificationManager.IMPORTANCE_LOW))
        val notification = notification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, notification)
        val cached = RaceRepository.cached(this)
        if (started != 0L && cached?.sessionId == race?.sessionId) return START_NOT_STICKY
        val ids = AppWidgetManager.getInstance(this).getAppWidgetIds(ComponentName(this, NextRaceWidgetProvider::class.java))
        if (cached == null || !NextRaceWidgetProvider.liveWindow(cached, System.currentTimeMillis()) || ids.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }
        generation++
        handler.removeCallbacksAndMessages(null)
        client?.close()
        retryDelay = 5_000L
        stopping = false
        race = cached
        AutoLiveScheduler.markHandled(this, cached)
        started = SystemClock.elapsedRealtime()
        connect()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun connect() {
        val id = ++generation
        state = LiveTimingState()
        lastMessage = SystemClock.elapsedRealtime()
        retryAt = 0L
        client = LiveTimingClient({ topic, data, timestamp ->
            handler.post {
                if (!stopping && generation == id) {
                    lastMessage = SystemClock.elapsedRealtime()
                    state.accept(topic, data, timestamp, lastMessage)
                    if (topic == "TimingData" && timestamp != null) retryDelay = 5_000L
                }
            }
        }, { handler.post { if (!stopping && generation == id) disconnect() } })
        client?.connect()
    }

    private fun disconnect() {
        generation++
        client?.close()
        client = null
        retryAt = SystemClock.elapsedRealtime() + retryDelay
        retryDelay = (retryDelay * 2).coerceAtMost(60_000L)
        publish()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (stopping) return
            val elapsed = SystemClock.elapsedRealtime()
            val currentRace = race ?: return
            // Bound this user-started connection to the race window, below Android's six-hour limit.
            if (elapsed - started >= currentRace.windowMillis ||
                !NextRaceWidgetProvider.liveWindow(currentRace, System.currentTimeMillis()) ||
                RaceRepository.cached(this@LiveRaceService)?.sessionId != currentRace.sessionId) {
                stopSelf(); return
            }
            if (client != null && elapsed - lastMessage > 45_000L) disconnect()
            if (client == null && elapsed >= retryAt) connect()
            client?.ping()
            val display = publish()
            if (display?.optBoolean("finished") == true) {
                RaceRepository.complete(this@LiveRaceService,currentRace)
                AutoLiveScheduler.schedule(this@LiveRaceService)
                stopSelf(); return
            }
            handler.postDelayed(this, 10_000L)
        }
    }

    private fun publish(): JSONObject? {
        val currentRace = race ?: return null
        val data = state.display(currentRace, System.currentTimeMillis(), SystemClock.elapsedRealtime())
        data.put("running", true)
        if (client == null) data.put("live", false).put("label", "RECONNECTING")
        LiveCache.save(this, data)
        NextRaceWidgetProvider.updateAll(this)
        return data
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getBroadcast(this, 77,
            Intent(this, NextRaceWidgetProvider::class.java).setAction(NextRaceWidgetProvider.STOP_LIVE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "live_race")
            .setSmallIcon(R.drawable.ic_live).setContentTitle("F1 live timing is running")
            .setContentText("Session timings update on your widget. Tap Stop to disconnect.")
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    }

    override fun onTimeout(startId: Int, fgsType: Int) { stopSelf() }

    override fun onDestroy() {
        stopping = true
        generation++
        handler.removeCallbacksAndMessages(null)
        client?.close()
        LiveCache.read(this)?.let {
            it.put("running", false).put("live", false)
            if (!it.optBoolean("finished")) it.put("label", "UPDATES STOPPED")
            LiveCache.save(this, it)
        }
        NextRaceWidgetProvider.updateAll(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
