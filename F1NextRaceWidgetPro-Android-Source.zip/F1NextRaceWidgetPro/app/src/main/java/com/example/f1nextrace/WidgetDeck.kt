package com.example.f1nextrace

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

internal object WidgetDeck {
    fun ids(c: Context)=AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c,NextRaceWidgetProvider::class.java))
    fun root(c: Context,id: Int): RemoteViews {
        val opts=AppWidgetManager.getInstance(c).getAppWidgetOptions(id)
        if(Build.VERSION.SDK_INT>=31) {
            val sizes=opts.getParcelableArrayList<SizeF>(AppWidgetManager.OPTION_APPWIDGET_SIZES)
                ?.filter { it.width>0 && it.height>0 }?.distinct()?.take(16)
            if(!sizes.isNullOrEmpty()) return RemoteViews(sizes.associateWith {
                sizedRoot(c,id,it.width.toInt(),it.height.toInt())
            })
        }
        val minW=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,340).coerceAtLeast(1)
        val minH=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,170).coerceAtLeast(1)
        val maxW=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,minW).coerceAtLeast(minW)
        val maxH=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,minH).coerceAtLeast(minH)
        return RemoteViews(sizedRoot(c,id,maxW,minH),sizedRoot(c,id,minW,maxH))
    }
    internal fun sizedRoot(c: Context,id: Int,width: Int,height: Int): RemoteViews {
        val v=RemoteViews(c.packageName,R.layout.widget_deck)
        val adapter=Intent(c,HistoryViewsService::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id)
            .putExtra("pageWidth",width).putExtra("pageHeight",height)
            .setData(Uri.parse("f1widget://flat/$id/${width}x${height}"))
        v.setRemoteAdapter(R.id.cards,adapter)
        val click=Intent(c,WidgetActionActivity::class.java).setData(Uri.parse("f1widget://action/$id"))
        v.setPendingIntentTemplate(R.id.cards,PendingIntent.getActivity(c,id,click,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE))
        return v
    }
    fun refresh(c: Context) {
        val manager=AppWidgetManager.getInstance(c)
        // Keep the list position when refreshing the same-size remote adapter.
        manager.notifyAppWidgetViewDataChanged(ids(c),R.id.cards)
    }
    fun fill(action: String,key: Long=0)=Intent().putExtra("widgetAction",action).putExtra("sessionKey",key)
    fun resultCard(c: Context,session: JSONObject?,compact: Boolean=false): RemoteViews {
        val v=RemoteViews(c.packageName,R.layout.widget_results)
        val rows=session?.optJSONArray("rows")
        val kind=SessionHistory.kind(session?.optString("session_name") ?: "")
        val published=rows!=null && rows.length()>0
        v.setTextViewText(R.id.result_heading,"F1 / ${kind?.label ?: "RESULTS"}")
        v.setTextViewText(R.id.result_status,if(published) "PUBLISHED" else "PENDING")
        v.setTextViewText(R.id.result_title,session?.optString("location")?.ifBlank { session.optString("country_name") } ?: "Previous sessions")
        val date=runCatching { DateTimeFormatter.ofPattern("EEE, dd MMM • h:mm a",Locale.ENGLISH)
            .format(Instant.parse(session!!.getString("date_start")).atZone(ZoneId.systemDefault())) }.getOrDefault("")
        v.setTextViewText(R.id.result_date,date)
        val rowIds=listOf(R.id.result_1,R.id.result_2,R.id.result_3,R.id.result_4,R.id.result_5)
        rowIds.forEachIndexed { i,id ->
            val show=published && i<rows!!.length() && i<(if(compact) 3 else 5)
            v.setViewVisibility(id,if(show) View.VISIBLE else View.GONE)
            if(show) v.setTextViewText(id,SessionHistory.line(rows!!.getJSONObject(i),kind?.racing==true))
        }
        v.setViewVisibility(R.id.result_empty,if(published) View.GONE else View.VISIBLE)
        v.setTextViewText(R.id.result_empty,if(session==null) "Connect to load previous sessions.\nScroll back to the first screen to return."
            else if(session.optLong("checked")==0L) "Results not downloaded yet.\nTap to load this session when online."
            else "Results not published yet.\nIf offline, reconnect to check again.")
        val stamp=session?.optLong("fetched") ?: 0
        val asOf=if(stamp>0) DateTimeFormatter.ofPattern("dd MMM HH:mm",Locale.ENGLISH)
            .format(Instant.ofEpochMilli(stamp).atZone(ZoneId.systemDefault())) else ""
        v.setTextViewText(R.id.result_footer,if(published) "SAVED $asOf  •  FULL RESULTS ↗" else "TAP TO CHECK RESULTS  ↻")
        val action=fill(if(published) "details" else "history",session?.optLong("session_key") ?: 0)
        v.setOnClickFillInIntent(R.id.result_content,action)
        return v
    }
}

class HistoryViewsService: RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext,
        intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1),
        intent.getIntExtra("pageWidth",340),intent.getIntExtra("pageHeight",170))
    internal class Factory(private val c: Context,private val id: Int,private val width: Int=340,private val height: Int=170): RemoteViewsFactory {
        private var sessions=listOf<JSONObject>()
        override fun onCreate() { onDataSetChanged() }
        override fun onDataSetChanged() { sessions=SessionHistory.read(c) }
        override fun onDestroy() {}
        override fun getCount()=1+sessions.size.coerceAtLeast(1)
        override fun getViewAt(position: Int): RemoteViews {
            val content=if(position==0) NextRaceWidgetProvider.renderWidget(c,showTrack=width>=320,collection=true)
                else WidgetDeck.resultCard(c,sessions.getOrNull(position-1),height<210)
            // Only the outer viewport draws the rounded background. No nested card edges.
            if(position!=0) content.setInt(R.id.result_content,"setBackgroundResource",0)
            val page=RemoteViews(c.packageName,R.layout.widget_page)
            page.setInt(R.id.page_height,"setHeight",(height*c.resources.displayMetrics.density).toInt())
            page.addView(R.id.page_content,content)
            return page
        }
        override fun getLoadingView()=RemoteViews(c.packageName,R.layout.widget_loading)
        override fun getViewTypeCount()=2
        override fun getItemId(position: Int)=if(position==0) 0L else sessions.getOrNull(position-1)?.optLong("session_key") ?: -1L
        override fun hasStableIds()=true
    }
}
