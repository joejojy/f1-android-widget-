package com.example.f1nextrace

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

class NextRaceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
        scheduleRefresh(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager,
        appWidgetId: Int, newOptions: Bundle) {
        updateWidget(context, manager, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleRefresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    ComponentName(context, NextRaceWidgetProvider::class.java)
                )
                ids.forEach { updateWidget(context, manager, it) }
                scheduleRefresh(context)
            }
        }
    }

    companion object {
        private const val PERIODIC_WORK = "f1_race_schedule_periodic_refresh"
        private const val ONE_TIME_WORK = "f1_race_schedule_initial_refresh"

        fun scheduleRefresh(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val periodic = PeriodicWorkRequestBuilder<RaceRefreshWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, periodic
            )
            val immediate = OneTimeWorkRequestBuilder<RaceRefreshWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                ONE_TIME_WORK, ExistingWorkPolicy.KEEP, immediate
            )
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            manager.updateAppWidget(widgetId, renderWidget(context))
        }

        internal fun renderWidget(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_next_race)
            val race = RaceRepository.cached(context)
            val zone = ZoneId.systemDefault()
            val updatedAt = RaceRepository.lastUpdated(context)

            if (race == null) {
                views.setTextViewText(R.id.race_name, "Finding your next Grand Prix")
                views.setTextViewText(R.id.circuit, "Connect to the internet to sync")
                views.setTextViewText(R.id.race_date, "Schedule will appear here")
                views.setChronometer(R.id.countdown, SystemClock.elapsedRealtime(), null, false)
                views.setTextViewText(R.id.countdown, "START  •  --:--:--")
                views.setTextViewText(R.id.status, "SYNCING")
            } else {
                val localStart = race.start.atZone(zone)
                val dateText = DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH)
                    .format(localStart).uppercase(Locale.ENGLISH)
                val timeText = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                    .format(localStart)
                // Map the scheduled wall-clock instant to Android's monotonic clock.
                // The launcher ticks this Chronometer without network or worker refreshes.
                // A signed clock crosses zero safely: negative BEFORE the scheduled start,
                // positive AFTER it. No exact-alarm permission or background service needed.
                val base = SystemClock.elapsedRealtime() +
                    (race.start.toEpochMilli() - System.currentTimeMillis())

                views.setTextViewText(R.id.race_name, race.name)
                val venue = listOf(race.locality, race.country).filter { it.isNotBlank() }.distinct().joinToString(", ")
                views.setTextViewText(R.id.circuit, venue.ifBlank { "Formula 1 World Championship" })
                views.setTextViewText(R.id.race_date, "$dateText  •  $timeText ${DateTimeFormatter.ofPattern("z", Locale.ENGLISH).format(localStart)}")
                views.setChronometerCountDown(R.id.countdown, false)
                views.setChronometer(R.id.countdown, base, "START  •  %s", true)
                views.setTextViewText(
                    R.id.status,
                    if (updatedAt > 0L) "AUTO-SYNC" else "CACHED"
                )
            }

            val openF1 = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.formula1.com/en/racing/2026.html")
            )
            val pending = PendingIntent.getActivity(
                context, 0, openF1,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.footer, pending)
            views.setOnClickPendingIntent(R.id.race_name, pending)
            return views
        }
    }
}
