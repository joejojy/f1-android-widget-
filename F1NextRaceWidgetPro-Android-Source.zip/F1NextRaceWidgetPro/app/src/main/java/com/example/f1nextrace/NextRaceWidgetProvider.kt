package com.example.f1nextrace

import android.app.PendingIntent
import android.app.AlarmManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.widget.RemoteViews
import android.view.View
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

class NextRaceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
        scheduleRefresh(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager,
        appWidgetId: Int, newOptions: Bundle) {
        updateWidget(context, manager, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleRefresh(context)
    }

    override fun onDisabled(context: Context) {
        AutoLiveScheduler.cancel(context)
        context.stopService(Intent(context, LiveRaceService::class.java))
        context.getSystemService(AlarmManager::class.java).cancel(minuteIntent(context))
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_WORK)
        WorkManager.getInstance(context).cancelUniqueWork(ONE_TIME_WORK)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            MINUTE_TICK -> updateAll(context)
            STOP_LIVE -> {
                AutoLiveScheduler.skipCurrentRace(context)
                context.stopService(Intent(context, LiveRaceService::class.java))
                updateAll(context)
            }
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    ComponentName(context, NextRaceWidgetProvider::class.java)
                )
                ids.forEach { updateWidget(context, manager, it) }
                scheduleRefresh(context)
            }
        }
    }

    companion object {
        private const val PERIODIC_WORK = "f1_race_schedule_periodic_refresh"
        private const val ONE_TIME_WORK = "f1_race_schedule_initial_refresh"
        const val STOP_LIVE = "com.example.f1nextrace.STOP_LIVE"
        private const val MINUTE_TICK = "com.example.f1nextrace.MINUTE_TICK"

        internal fun liveWindow(race: RaceInfo, now: Long): Boolean =
            now - race.start.toEpochMilli() in -1_800_000L until race.windowMillis

        internal fun countdown(start: Long, now: Long): String {
            val remaining = start - now
            if (remaining <= 0) return "SCHEDULED START REACHED"
            val total = (remaining + 59_999L) / 60_000L
            val days = total / 1440
            val hours = total / 60 % 24
            val minutes = total % 60
            return "START IN  •  " + (if (days > 0) "${days}d " else "") + "${hours}h ${minutes}m"
        }

        private fun minuteIntent(context: Context) = PendingIntent.getBroadcast(context, 90,
            Intent(context, NextRaceWidgetProvider::class.java).setAction(MINUTE_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        private fun scheduleMinute(context: Context) {
            // Local, non-waking updates: no network polling or per-second work.
            // Android may defer these in battery saver/Doze; every render recomputes from UTC.
            val delay = 60_000L - System.currentTimeMillis() % 60_000L
            context.getSystemService(AlarmManager::class.java).set(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + delay, minuteIntent(context))
        }

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, NextRaceWidgetProvider::class.java))
                .forEach { updateWidget(context, manager, it) }
        }

        fun scheduleRefresh(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val periodic = PeriodicWorkRequestBuilder<RaceRefreshWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, periodic
            )
            val immediate = OneTimeWorkRequestBuilder<RaceRefreshWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                ONE_TIME_WORK, ExistingWorkPolicy.KEEP, immediate
            )
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val width = manager.getAppWidgetOptions(widgetId)
                .getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            manager.updateAppWidget(widgetId, renderWidget(context,
                showTrack = width == 0 || width >= 320))
            scheduleMinute(context)
            AutoLiveScheduler.schedule(context)
        }

        internal fun renderWidget(
            context: Context,
            nowMillis: Long = System.currentTimeMillis(),
            elapsedMillis: Long = SystemClock.elapsedRealtime(),
            showTrack: Boolean = true
        ): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_next_race)
            val race = RaceRepository.cached(context,java.time.Instant.ofEpochMilli(nowMillis))
            views.setTextViewText(R.id.session_heading, "F1  /  ${race?.kind?.label ?: "RACE WEEKEND"}")
            val track = race?.let { CircuitLayouts.resourceFor(it.circuitId) } ?: 0
            views.setViewVisibility(R.id.track_outline,
                if (showTrack && track != 0) View.VISIBLE else View.GONE)
            if (showTrack && track != 0) {
                views.setImageViewResource(R.id.track_outline, track)
                val trackName = race?.circuitName?.takeIf { it.isNotBlank() }
                    ?: race?.name ?: "Circuit"
                views.setContentDescription(R.id.track_outline,
                    "$trackName track layout")
            }
            val zone = ZoneId.systemDefault()
            val updatedAt = RaceRepository.lastUpdated(context)

            if (race == null) {
                views.setTextViewText(R.id.race_name, "Finding your next Grand Prix")
                views.setTextViewText(R.id.circuit, "Connect to the internet to sync")
                views.setTextViewText(R.id.race_date, "Schedule will appear here")
                views.setTextViewText(R.id.countdown, "START IN  •  —")
                views.setTextViewText(R.id.status, "SYNCING")
            } else {
                val localStart = race.start.atZone(zone)
                val dateText = DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH)
                    .format(localStart).uppercase(Locale.ENGLISH)
                val timeText = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                    .format(localStart)
                views.setTextViewText(R.id.race_name, race.name)
                val venue = listOf(race.locality, race.country).filter { it.isNotBlank() }.distinct().joinToString(", ")
                views.setTextViewText(R.id.circuit, venue.ifBlank { "Formula 1 World Championship" })
                views.setTextViewText(R.id.race_date, "$dateText  •  $timeText ${DateTimeFormatter.ofPattern("z", Locale.ENGLISH).format(localStart)}")
                views.setTextViewText(R.id.countdown, countdown(race.start.toEpochMilli(), nowMillis))
                views.setTextViewText(
                    R.id.status,
                    if (updatedAt > 0L) "AUTO-SYNC" else "CACHED"
                )
            }

            views.setTextViewText(R.id.footer, "TAP TO OPEN F1 CALENDAR  ↗")
            val saved = LiveCache.read(context)?.takeIf {
                if (it.has("sessionId")) it.optString("sessionId") == race?.sessionId
                else race?.kind == SessionKind.RACE && it.optString("raceStart") == race.start.toString()
            }
            val active = LiveCache.active(saved, nowMillis, elapsedMillis)
            val live = active && saved?.optBoolean("live") == true &&
                nowMillis - saved.optLong("timingAt") in -5_000L..30_000L
            val rows = saved?.optJSONArray("rows")
            val showRows = race != null && nowMillis >= race.start.toEpochMilli() && rows?.length() == 5
            views.setViewVisibility(R.id.race_details, if (showRows) View.GONE else View.VISIBLE)
            views.setViewVisibility(R.id.live_rows, if (showRows) View.VISIBLE else View.GONE)
            if (showRows) {
                listOf(R.id.driver_1, R.id.driver_2, R.id.driver_3, R.id.driver_4, R.id.driver_5)
                    .forEachIndexed { index, id -> views.setTextViewText(id, rows!!.getString(index)) }
                val label = when {
                    live -> "LIVE  •  ${saved!!.optString("detail")}".trim().trimEnd('•').trim()
                    saved!!.optBoolean("finished") -> "SESSION ENDED"
                    active -> saved.optString("label").let { if (it == "LIVE") "STALE DATA" else it }
                    else -> "LAST KNOWN"
                }
                views.setTextViewText(R.id.status, label)
                if (!live) {
                    val timestamp = saved!!.optLong("timingAt")
                    val time = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                        .format(java.time.Instant.ofEpochMilli(timestamp).atZone(zone))
                    views.setTextViewText(R.id.footer, "AS OF $time  •  F1 ↗")
                }
            } else if (active) views.setTextViewText(R.id.status, saved!!.optString("label"))

            val settings = PendingIntent.getActivity(context, 79, Intent(context, LiveSettingsActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.status, settings)
            views.setContentDescription(R.id.status, "Live timing status. Tap for automatic live settings.")
            val offerLive = race != null && liveWindow(race, nowMillis)
            val autoReady = AutoLiveScheduler.enabled(context) && AutoLiveScheduler.permitted(context)
            val autoWaiting = autoReady && race != null && !AutoLiveScheduler.handled(context, race)
            views.setViewVisibility(R.id.live_action, View.VISIBLE)
            if (offerLive || active || autoWaiting) {
                if (!showRows || live) views.setTextViewText(R.id.footer, "F1 CALENDAR  ↗")
                views.setTextViewText(R.id.live_action, when {
                    active -> "STOP LIVE  ■"
                    autoWaiting -> "AUTO ON"
                    else -> "START LIVE  ▶"
                })
                val action = if (active) PendingIntent.getBroadcast(context, 77,
                    Intent(context, NextRaceWidgetProvider::class.java).setAction(STOP_LIVE),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                else if (autoWaiting) settings
                else PendingIntent.getForegroundService(context, 78, Intent(context, LiveRaceService::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.live_action, action)
            } else {
                views.setTextViewText(R.id.footer, "F1 CALENDAR  ↗")
                views.setTextViewText(R.id.live_action, if (autoReady) "AUTO ON" else "AUTO LIVE")
                views.setOnClickPendingIntent(R.id.live_action, settings)
            }
            views.setOnClickPendingIntent(R.id.countdown, minuteIntent(context))

            val openF1 = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.formula1.com/en/racing/2026.html")
            )
            val pending = PendingIntent.getActivity(
                context, 0, openF1,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.footer, pending)
            views.setOnClickPendingIntent(R.id.race_name, pending)
            return views
        }
    }
}
