package com.example.f1nextrace

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

class NextRaceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
        scheduleRefresh(context)
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleRefresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    ComponentName(context, NextRaceWidgetProvider::class.java)
                )
                ids.forEach { updateWidget(context, manager, it) }
                scheduleRefresh(context)
            }
        }
    }

    companion object {
        private const val PERIODIC_WORK = "f1_race_schedule_periodic_refresh"
        private const val ONE_TIME_WORK = "f1_race_schedule_initial_refresh"

        fun scheduleRefresh(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val periodic = PeriodicWorkRequestBuilder<RaceRefreshWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, periodic
            )
            val immediate = OneTimeWorkRequestBuilder<RaceRefreshWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                ONE_TIME_WORK, ExistingWorkPolicy.KEEP, immediate
            )
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_next_race)
            val race = RaceRepository.cached(context)
            val zone = ZoneId.systemDefault()
            val updatedAt = RaceRepository.lastUpdated(context)

            if (race == null) {
                views.setTextViewText(R.id.race_name, "Finding your next Grand Prix")
                views.setTextViewText(R.id.circuit, "Connect to the internet to sync")
                views.setTextViewText(R.id.race_date, "Schedule will appear here")
                views.setTextViewText(R.id.countdown, "RACE IN  •  --d --h --m")
                views.setTextViewText(R.id.status, "SYNCING")
            } else {
                val localStart = race.start.atZone(zone)
                val dateText = DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH)
                    .format(localStart).uppercase(Locale.ENGLISH)
                val timeText = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                    .format(localStart)
                val seconds = Duration.between(java.time.Instant.now(), race.start).seconds.coerceAtLeast(0)
                val days = seconds / 86400
                val hours = (seconds % 86400) / 3600
                val minutes = (seconds % 3600) / 60

                views.setTextViewText(R.id.race_name, race.name)
                val venue = listOf(race.locality, race.country).filter { it.isNotBlank() }.distinct().joinToString(", ")
                views.setTextViewText(R.id.circuit, venue.ifBlank { "Formula 1 World Championship" })
                views.setTextViewText(R.id.race_date, "$dateText  •  $timeText ${localStart.zone.id}")
                views.setTextViewText(R.id.countdown, "RACE IN  •  %02dd %02dh %02dm".format(days, hours, minutes))
                views.setTextViewText(
                    R.id.status,
                    if (updatedAt > 0L) "AUTO-SYNC" else "CACHED"
                )
            }

            val openF1 = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.formula1.com/en/racing/2026.html")
            )
            val pending = PendingIntent.getActivity(
                context, 0, openF1,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.footer, pending)
            views.setOnClickPendingIntent(R.id.race_name, pending)
            manager.updateAppWidget(widgetId, views)
        }
    }
}
