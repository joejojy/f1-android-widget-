package com.example.f1nextrace

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class HistoryWorker(c: Context, p: WorkerParameters): CoroutineWorker(c,p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ok=runCatching { SessionHistory.refresh(applicationContext) }.isSuccess
        WidgetDeck.refresh(applicationContext)
        if(ok) Result.success() else if(runAttemptCount<2) Result.retry() else Result.failure()
    }
    companion object {
        private val network=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        fun schedule(c: Context) {
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("f1_history_periodic",ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<HistoryWorker>(15,TimeUnit.MINUTES).setConstraints(network).build())
            request(c)
        }
        fun request(c: Context) {
            WorkManager.getInstance(c).enqueueUniqueWork("f1_history_refresh",ExistingWorkPolicy.KEEP,
                OneTimeWorkRequestBuilder<HistoryWorker>().setConstraints(network)
                    .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,10,TimeUnit.MINUTES).build())
        }
        fun cancel(c: Context) {
            WorkManager.getInstance(c).cancelUniqueWork("f1_history_periodic")
            WorkManager.getInstance(c).cancelUniqueWork("f1_history_refresh")
        }
    }
}
