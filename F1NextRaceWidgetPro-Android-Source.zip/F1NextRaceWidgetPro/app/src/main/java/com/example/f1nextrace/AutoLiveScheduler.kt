package com.example.f1nextrace

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build

internal object AutoLiveScheduler {
    const val ACTION_START = "com.example.f1nextrace.AUTO_START_RACE"
    const val EXTRA_RACE = "race_start"
    private fun prefs(context: Context) = context.getSharedPreferences("f1_auto_live", Context.MODE_PRIVATE)
    fun enabled(context: Context) = prefs(context).getBoolean("enabled", false)
    fun permitted(context: Context) = Build.VERSION.SDK_INT < 31 ||
        context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun hasWidgets(context: Context) = AppWidgetManager.getInstance(context)
        .getAppWidgetIds(ComponentName(context, NextRaceWidgetProvider::class.java)).isNotEmpty()
    private fun handledIds(context: Context) = prefs(context).getStringSet("handled_sessions",emptySet())!!.toSet()
    fun handled(context: Context, race: RaceInfo) = race.sessionId in handledIds(context)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("enabled", enabled).apply()
        if (!enabled) cancel(context)
    }

    private fun pending(context: Context, race: RaceInfo? = null) = PendingIntent.getBroadcast(context, 91,
        Intent(context, AutoLiveAlarmReceiver::class.java).setAction(ACTION_START)
            .putExtra(EXTRA_RACE, race?.sessionId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun cancel(context: Context) = context.getSystemService(AlarmManager::class.java).cancel(pending(context))

    internal fun triggerTime(race: RaceInfo?, now: Long, enabled: Boolean, permitted: Boolean,
        hasWidgets: Boolean, handled: Boolean): Long? {
        if (race == null || !enabled || !permitted || !hasWidgets || handled) return null
        val start = race.start.toEpochMilli()
        if (now >= start + race.windowMillis) return null
        // A one-shot catch-up alarm also covers enabling the feature during a race or rebooting late.
        return maxOf(start, now + 1_000L)
    }

    fun schedule(context: Context, now: Long = System.currentTimeMillis()) {
        val race = RaceRepository.nextForAuto(context,java.time.Instant.ofEpochMilli(now),handledIds(context))
        val trigger = triggerTime(race, now, enabled(context), permitted(context), hasWidgets(context),
            race != null && handled(context, race))
        if (trigger == null) { cancel(context); return }
        try {
            context.getSystemService(AlarmManager::class.java).setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, trigger, pending(context, race))
        } catch (_: SecurityException) {
            // Permission can be revoked between checking and scheduling. Manual live remains available.
            cancel(context)
        }
    }

    fun markHandled(context: Context, race: RaceInfo) {
        // Persist before launching so a service stop, reboot or repeated broadcast cannot restart this race.
        prefs(context).edit().putStringSet("handled_sessions", handledIds(context) + race.sessionId).commit()
        cancel(context)
        schedule(context)
    }

    fun skipCurrentRace(context: Context) { RaceRepository.cached(context)?.let { markHandled(context, it) } }

    internal fun startFromAlarm(context: Context, intent: Intent, now: Long = System.currentTimeMillis()) {
        val race = RaceRepository.cached(context,java.time.Instant.ofEpochMilli(now)) ?: return
        if (intent.action != ACTION_START || intent.getStringExtra(EXTRA_RACE) != race.sessionId ||
            !enabled(context) || !permitted(context) || !hasWidgets(context) || handled(context, race) ||
            now < race.start.toEpochMilli() || !NextRaceWidgetProvider.liveWindow(race, now)) return
        markHandled(context, race)
        try {
            // User-enabled exact alarms are an Android exemption for starting a foreground service.
            context.startForegroundService(Intent(context, LiveRaceService::class.java))
        } catch (_: IllegalStateException) {
            // Manufacturer/OS restrictions: leave START LIVE available instead of repeatedly retrying.
        } catch (_: SecurityException) { }
        NextRaceWidgetProvider.updateAll(context)
    }
}

class AutoLiveAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AutoLiveScheduler.startFromAlarm(context, intent)
    }
}
