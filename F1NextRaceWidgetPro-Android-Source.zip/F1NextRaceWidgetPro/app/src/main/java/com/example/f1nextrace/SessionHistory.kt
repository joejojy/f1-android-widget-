package com.example.f1nextrace

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.Locale
import java.util.concurrent.TimeUnit

internal object SessionHistory {
    private fun prefs(c: Context) = c.getSharedPreferences("f1_history", Context.MODE_PRIVATE)
    fun read(c: Context): List<JSONObject> = runCatching {
        objects(JSONArray(prefs(c).getString("sessions", "[]")))
    }.getOrDefault(emptyList())
    fun save(c: Context, sessions: List<JSONObject>) {
        prefs(c).edit().putString("sessions", JSONArray(sessions).toString()).commit()
    }
    fun request(c: Context,key: Long,manual: Boolean=false) {
        val edit=prefs(c).edit()
        if(key>0) edit.putLong("requested",key)
        if(manual) edit.putBoolean("manual_refresh",true)
        edit.apply()
    }
    fun objects(a: JSONArray) = (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    fun kind(name: String): SessionKind? = when(name.lowercase(Locale.ROOT)) {
        "practice 1" -> SessionKind.PRACTICE_1
        "practice 2" -> SessionKind.PRACTICE_2
        "practice 3" -> SessionKind.PRACTICE_3
        "qualifying" -> SessionKind.QUALIFYING
        "sprint qualifying", "sprint shootout" -> SessionKind.SPRINT_QUALIFYING
        "sprint" -> SessionKind.SPRINT
        "race" -> SessionKind.RACE
        else -> null
    }
    fun candidates(data: JSONArray, now: Instant): List<JSONObject> = objects(data).filter {
        !it.optBoolean("is_cancelled") && kind(it.optString("session_name")) != null && it.optLong("session_key") > 0 &&
            runCatching { !Instant.parse(it.getString("date_end")).isAfter(now) }.getOrDefault(false)
    }.distinctBy { it.getLong("session_key") }.sortedByDescending { Instant.parse(it.getString("date_end")) }.take(14)

    fun results(data: JSONArray, sessionKey: Long): List<JSONObject> {
        val rows = objects(data).filter { it.optLong("session_key") == sessionKey && it.optInt("driver_number") > 0 }
            .distinctBy { it.getInt("driver_number") }
        // Preserve published classification; never sort qualifying by best time across parts.
        return rows.sortedBy { if (it.optInt("position") > 0) it.getInt("position") else Int.MAX_VALUE }
    }
    // Keep only the latest completed event day, not a rolling archive of weekends.
    // Venue time keeps late-night sessions on their actual racing day for all users.
    internal fun latestDay(sessions: List<JSONObject>): List<JSONObject> {
        val sorted=sessions.filter { kind(it.optString("session_name"))!=null }
            .sortedByDescending { it.optString("date_end",it.optString("date_start")) }
        val newest=sorted.firstOrNull() ?: return emptyList()
        fun day(s: JSONObject)=runCatching {
            val offset=runCatching { java.time.ZoneOffset.of(s.optString("gmt_offset","Z")) }.getOrDefault(java.time.ZoneOffset.UTC)
            Instant.parse(s.getString("date_start")).atOffset(offset).toLocalDate()
        }.getOrNull()
        val date=day(newest) ?: return listOf(newest)
        return sorted.filter { day(it)==date &&
            if(newest.has("meeting_key")) it.optLong("meeting_key")==newest.optLong("meeting_key")
            else it.optString("location")==newest.optString("location") }
    }
    fun lap(seconds: Double): String = if (!seconds.isFinite() || seconds <= 0) "—" else {
        val ms = Math.round(seconds * 1000)
        String.format(Locale.US, "%d:%02d.%03d", ms / 60000, ms / 1000 % 60, ms % 1000)
    }
    fun timing(row: JSONObject, racing: Boolean): String {
        if (row.optBoolean("dsq")) return "DSQ"
        if (row.optBoolean("dns")) return "DNS"
        if (row.optBoolean("dnf")) return "DNF"
        if (!racing) {
            val parts = row.optJSONArray("duration")
            if (parts != null) {
                for (i in parts.length()-1 downTo 0) if (parts.optDouble(i,0.0) > 0)
                    return "Q${i+1} ${lap(parts.getDouble(i))}"
                return "—"
            }
            return lap(row.optDouble("duration",0.0))
        }
        if (row.optInt("position") == 1) return "WINNER"
        val gap = row.opt("gap_to_leader")
        return when(gap) {
            is Number -> String.format(Locale.US,"+%.3f",gap.toDouble())
            is String -> gap.takeIf { it.isNotBlank() } ?: "—"
            else -> "—"
        }
    }
    fun line(row: JSONObject, racing: Boolean): String {
        val position = row.optInt("position").takeIf { it > 0 }?.toString() ?: "—"
        return "$position  ${row.optString("name", "#${row.optInt("driver_number")}")}  ${timing(row,racing)}"
    }
    private val client = OkHttpClient.Builder().connectTimeout(12,TimeUnit.SECONDS)
        .readTimeout(15,TimeUnit.SECONDS).callTimeout(20,TimeUnit.SECONDS).build()

    // Runs only in a worker, never on the widget/launcher thread. Injected getter makes tests offline.
    @Synchronized fun refresh(c: Context, now: Instant = Instant.now(), get: ((String,Map<String,String>)->JSONArray)? = null) {
        val nowMs=now.toEpochMilli()
        val requested=prefs(c).getLong("requested",0)
        val requestedSession=read(c).firstOrNull { it.optLong("session_key")==requested }
        val prioritise=requestedSession!=null && requestedSession.optJSONArray("rows")==null &&
            nowMs-requestedSession.optLong("checked")>60_000L
        val sinceAttempt=nowMs-prefs(c).getLong("attempt",0)
        val manual=prefs(c).getBoolean("manual_refresh",false) && sinceAttempt>=60_000L
        if (!prioritise && !manual && sinceAttempt in 0 until 10*60_000L) return
        prefs(c).edit().putLong("attempt",nowMs).putBoolean("manual_refresh",false).apply()
        val fetch = get ?: { path: String, args: Map<String,String> ->
            Thread.sleep(400) // Stay below the public endpoint's short-window rate limit.
            val url="https://api.openf1.org/v1/$path".toHttpUrl().newBuilder()
            args.forEach { (k,v)->url.addQueryParameter(k,v) }
            client.newCall(Request.Builder().url(url.build()).build()).execute().use {
                check(it.isSuccessful) { "Results service ${it.code}" }
                JSONArray(it.body!!.string())
            }
        }
        val old=read(c).associateBy { it.optLong("session_key") }
        // The query separator supplies '=': OpenF1 expects date_start>=value,
        // not a field named 'date_start>=' followed by a second equals sign.
        val found=latestDay(candidates(fetch("sessions",mapOf("date_start>" to now.minusSeconds(60L*86400).toString(), "date_end<" to now.toString())),now))
        if(found.isEmpty()) return // An empty provider response must not erase offline history.
        val entries=found.map { meta ->
            val saved=old[meta.getLong("session_key")]
            if(saved!=null) for(key in listOf("rows","fetched","checked")) if(saved.has(key)) meta.put(key,saved.get(key))
            meta
        }
        save(c,entries)
        // Re-check recent classifications for penalties; backfill older sessions over bounded runs.
        val due=entries.filter {
            val age=nowMs-Instant.parse(it.getString("date_end")).toEpochMilli()
            val interval=if(it.optJSONArray("rows")==null) 15*60_000L else if(age<2*86400_000L) 60*60_000L else 7*86400_000L
            (prioritise && it.optLong("session_key")==requested) || nowMs-it.optLong("checked") >= interval
        }.sortedWith(compareBy<JSONObject> { if(prioritise && it.optLong("session_key")==requested) -1 else if(it.optJSONArray("rows")==null) 0 else 1 }.thenBy { it.optLong("checked") }).take(4)
        for(entry in due) {
            val key=entry.getLong("session_key")
            val rows=results(fetch("session_result",mapOf("session_key" to "$key")),key)
            if(rows.isNotEmpty()) {
                val names=objects(fetch("drivers",mapOf("session_key" to "$key"))).associate {
                    it.optInt("driver_number") to it.optString("last_name").ifBlank { it.optString("name_acronym") }
                }
                rows.forEach { it.put("name",names[it.getInt("driver_number")]?.takeIf { n->n.isNotBlank() } ?: "#${it.getInt("driver_number")}") }
                entry.put("rows",JSONArray(rows)).put("fetched",nowMs)
            }
            entry.put("checked",nowMs)
            save(c,entries) // Keep each successful response if a later request fails.
        }
    }
}
