package com.example.f1nextrace

import org.json.JSONObject
import java.time.OffsetDateTime
import kotlin.math.abs

/** SignalR sends sparse patches, not complete driver rows. Keep one state per connection. */
internal class LiveTimingState {
    private val topics = JSONObject()
    private var timingAt = 0L
    private var receivedAt = 0L

    fun accept(topic: String, data: JSONObject, timestamp: String?, elapsed: Long) {
        val previous = topics.optJSONObject(topic) ?: JSONObject().also { topics.put(topic, it) }
        if (topic == "SessionInfo" && data.has("Key") && previous.has("Key") &&
            data.optString("Key") != previous.optString("Key")) {
            topics.keys().asSequence().toList().forEach { topics.remove(it) }
            timingAt = 0L
        }
        val target = topics.optJSONObject(topic) ?: JSONObject().also { topics.put(topic, it) }
        merge(target, data)
        if (topic == "TimingData" && timestamp != null && part() in 1..3) {
            // BestLapTime corrections (including deleted laps) supersede stored part-best values.
            val patches = data.optJSONObject("Lines")
            patches?.keys()?.forEach { driver ->
                val best = patches.optJSONObject(driver)?.optJSONObject("BestLapTime")
                if (best?.has("Value") == true) {
                    val row = target.optJSONObject("Lines")?.optJSONObject(driver)
                    val times = row?.optJSONObject("BestLapTimes") ?: JSONObject()
                    times.put((part()-1).toString(),JSONObject().put("Value",best.optString("Value")))
                    row?.put("BestLapTimes",times)
                }
            }
        }
        if (topic == "TimingData" && timestamp != null) {
            val instant = runCatching { java.time.Instant.parse(timestamp).toEpochMilli() }.getOrNull()
            if (instant != null && instant >= timingAt) {
                timingAt = instant
                receivedAt = elapsed
            }
        }
    }

    fun display(race: RaceInfo, now: Long, elapsed: Long): JSONObject {
        val info = topics.optJSONObject("SessionInfo") ?: JSONObject()
        val start = runCatching {
            val offset = info.getString("GmtOffset").let { if (it.startsWith("-") || it.startsWith("+")) it else "+$it" }
            OffsetDateTime.parse(info.getString("StartDate") + offset)
                .toInstant().toEpochMilli()
        }.getOrDefault(0L)
        val matching = race.kind.matches(info.optString("Type"),info.optString("Name")) &&
            abs(start - race.start.toEpochMilli()) <= 1_800_000L
        val status = topics.optJSONObject("SessionStatus")?.optString("Status").orEmpty()
        val fresh = timingAt > 0 && now - timingAt in -5_000L..30_000L &&
            elapsed - receivedAt in 0L..30_000L
        val drivers = topics.optJSONObject("DriverList") ?: JSONObject()
        val lines = topics.optJSONObject("TimingData")?.optJSONObject("Lines") ?: JSONObject()
        val part = part()
        var hasLapTime = false
        val rows = lines.keys().asSequence().mapNotNull { number ->
            val row = lines.optJSONObject(number) ?: return@mapNotNull null
            val position = row.optString("Position").toIntOrNull() ?: return@mapNotNull null
            if (position !in 1..5) return@mapNotNull null
            val driver = drivers.optJSONObject(number) ?: return@mapNotNull null
            val name = driver.optString("LastName").ifBlank { driver.optString("Tla") }
            if (name.isBlank()) return@mapNotNull null
            val gap = when {
                !race.kind.racing -> {
                    val times = row.optJSONObject("BestLapTimes")
                    val time = if (race.kind.qualifying && part in 1..3)
                        times?.optJSONObject((part-1).toString())?.optString("Value").orEmpty()
                    else row.optJSONObject("BestLapTime")?.optString("Value").orEmpty()
                    if (time.isNotBlank()) hasLapTime = true
                    time.ifBlank { "—" }
                }
                row.optBoolean("Retired") -> "OUT"
                row.optBoolean("InPit") -> "PIT"
                position == 1 -> "LEADER"
                else -> row.optString("GapToLeader").ifBlank { "—" }
            }
            position to "$position  ${name.uppercase(java.util.Locale.ENGLISH)}   $gap"
        }.sortedBy { it.first }.toList()
        val complete = rows.map { it.first } == listOf(1, 2, 3, 4, 5)
        // Qualifying reports Finished between its parts; wait for finalisation there.
        val finished = matching && (status in listOf("Finalised","Ends") ||
            (status == "Finished" && !race.kind.qualifying))
        val canShow = matching && complete && timingAt > 0
        val label = when {
            !matching -> "WAITING FOR SESSION"
            finished -> "SESSION ENDED"
            status == "Aborted" -> "SESSION PAUSED"
            status == "Finished" && race.kind.qualifying -> "SESSION BREAK"
            status != "Started" -> "WAITING FOR START"
            !complete || !fresh -> "WAITING FOR DATA"
            !race.kind.racing && !hasLapTime -> "WAITING FOR TIMES"
            else -> "LIVE"
        }
        val lap = topics.optJSONObject("LapCount")
        val detail = if (race.kind.racing) {
            if (lap != null) "LAP ${lap.optInt("CurrentLap")}/${lap.optInt("TotalLaps")}" else "POSITIONS"
        } else if (race.kind.qualifying && part in 1..3) {
            (if (race.kind == SessionKind.SPRINT_QUALIFYING) "SQ" else "Q") + part + " BEST"
        } else "BEST LAP"
        return JSONObject().put("raceStart", race.start.toString()).put("sessionId",race.sessionId)
            .put("detail",detail)
            .put("label", label).put("live", label == "LIVE").put("finished", finished)
            .put("rows", if (canShow) org.json.JSONArray(rows.map { it.second }) else org.json.JSONArray())
            .put("lap", if (lap != null) "${lap.optInt("CurrentLap")}/${lap.optInt("TotalLaps")}" else "")
            .put("timingAt", timingAt).put("tickElapsed", elapsed).put("tickWall", now)
    }

    private fun merge(target: JSONObject, patch: JSONObject) {
        patch.keys().forEach { key ->
            val value = normalize(patch.get(key))
            val old = target.optJSONObject(key)
            if (value is JSONObject && old != null) merge(old, value) else target.put(key, value)
        }
    }

    private fun part(): Int {
        val series = topics.optJSONObject("SessionData")?.optJSONObject("Series")
        val fromSeries = series?.keys()?.asSequence()?.mapNotNull { key ->
            key.toIntOrNull()?.let { it to (series.optJSONObject(key)?.optInt("QualifyingPart",0) ?: 0) }
        }?.sortedBy { it.first }?.lastOrNull()?.second ?: 0
        return maxOf(topics.optJSONObject("TimingData")?.optInt("SessionPart",0) ?: 0,fromSeries)
    }

    private fun normalize(value: Any): Any = when(value) {
        is org.json.JSONArray -> JSONObject().also { result ->
            for(i in 0 until value.length()) result.put(i.toString(),normalize(value.get(i)))
        }
        is JSONObject -> JSONObject().also { result -> value.keys().forEach { result.put(it,normalize(value.get(it))) } }
        else -> value
    }
}
