package com.example.f1nextrace

import org.json.JSONObject
import java.time.OffsetDateTime
import kotlin.math.abs

/** SignalR sends sparse patches, not complete driver rows. Keep one state per connection. */
internal class LiveTimingState {
    private val topics = JSONObject()
    private var timingAt = 0L
    private var receivedAt = 0L

    fun accept(topic: String, data: JSONObject, timestamp: String?, elapsed: Long) {
        val previous = topics.optJSONObject(topic) ?: JSONObject().also { topics.put(topic, it) }
        if (topic == "SessionInfo" && data.has("Key") && previous.has("Key") &&
            data.optString("Key") != previous.optString("Key")) {
            topics.keys().asSequence().toList().forEach { topics.remove(it) }
            timingAt = 0L
        }
        val target = topics.optJSONObject(topic) ?: JSONObject().also { topics.put(topic, it) }
        merge(target, data)
        if (topic == "TimingData" && timestamp != null) {
            val instant = runCatching { java.time.Instant.parse(timestamp).toEpochMilli() }.getOrNull()
            if (instant != null && instant >= timingAt) {
                timingAt = instant
                receivedAt = elapsed
            }
        }
    }

    fun display(race: RaceInfo, now: Long, elapsed: Long): JSONObject {
        val info = topics.optJSONObject("SessionInfo") ?: JSONObject()
        val start = runCatching {
            val offset = info.getString("GmtOffset").let { if (it.startsWith("-") || it.startsWith("+")) it else "+$it" }
            OffsetDateTime.parse(info.getString("StartDate") + offset)
                .toInstant().toEpochMilli()
        }.getOrDefault(0L)
        val matching = info.optString("Type") == "Race" &&
            abs(start - race.start.toEpochMilli()) <= 3_600_000L
        val status = topics.optJSONObject("SessionStatus")?.optString("Status").orEmpty()
        val fresh = timingAt > 0 && now - timingAt in -5_000L..30_000L &&
            elapsed - receivedAt in 0L..30_000L
        val drivers = topics.optJSONObject("DriverList") ?: JSONObject()
        val lines = topics.optJSONObject("TimingData")?.optJSONObject("Lines") ?: JSONObject()
        val rows = lines.keys().asSequence().mapNotNull { number ->
            val row = lines.optJSONObject(number) ?: return@mapNotNull null
            val position = row.optString("Position").toIntOrNull() ?: return@mapNotNull null
            if (position !in 1..5) return@mapNotNull null
            val driver = drivers.optJSONObject(number) ?: return@mapNotNull null
            val name = driver.optString("LastName").ifBlank { driver.optString("Tla") }
            if (name.isBlank()) return@mapNotNull null
            val gap = when {
                row.optBoolean("Retired") -> "OUT"
                row.optBoolean("InPit") -> "PIT"
                position == 1 -> "LEADER"
                else -> row.optString("GapToLeader").ifBlank { "—" }
            }
            position to "$position  ${name.uppercase(java.util.Locale.ENGLISH)}   $gap"
        }.sortedBy { it.first }.toList()
        val complete = rows.map { it.first } == listOf(1, 2, 3, 4, 5)
        val finished = matching && status in listOf("Finished", "Finalised", "Ends")
        val canShow = matching && complete && timingAt > 0
        val label = when {
            !matching -> "WAITING FOR RACE"
            finished -> "SESSION ENDED"
            status == "Aborted" -> "RACE SUSPENDED"
            status != "Started" -> "WAITING FOR START"
            !complete || !fresh -> "WAITING FOR DATA"
            else -> "LIVE"
        }
        val lap = topics.optJSONObject("LapCount")
        return JSONObject().put("raceStart", race.start.toString())
            .put("label", label).put("live", label == "LIVE").put("finished", finished)
            .put("rows", if (canShow) org.json.JSONArray(rows.map { it.second }) else org.json.JSONArray())
            .put("lap", if (lap != null) "${lap.optInt("CurrentLap")}/${lap.optInt("TotalLaps")}" else "")
            .put("timingAt", timingAt).put("tickElapsed", elapsed).put("tickWall", now)
    }

    private fun merge(target: JSONObject, patch: JSONObject) {
        patch.keys().forEach { key ->
            val value = patch.get(key)
            val old = target.optJSONObject(key)
            if (value is JSONObject && old != null) merge(old, value) else target.put(key, value)
        }
    }
}
