plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.f1nextrace"
    compileSdk = 35
    testOptions { unitTests.isIncludeAndroidResources = true }
    defaultConfig {
        applicationId = "com.example.f1nextrace"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "2.2"
    }
}
dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}

// Keep the existing Actions build entry point, with regression checks first.
tasks.matching { it.name == "assembleDebug" }.configureEach {
    dependsOn("testDebugUnitTest")
}
tasks.withType<Test>().configureEach {
    testLogging {
        showStandardStreams = true
        events("passed", "failed")
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}
