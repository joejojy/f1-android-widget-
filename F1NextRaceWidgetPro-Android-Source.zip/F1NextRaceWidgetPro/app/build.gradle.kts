plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.f1nextrace"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.f1nextrace"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
