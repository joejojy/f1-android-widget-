# F1 Next Race Widget — Pro

A native Android home-screen widget for the next Formula 1 Grand Prix.

## Features
- Fetches the current season race schedule from the community-maintained Jolpica F1 API.
- Finds the next race with a future start time.
- Converts the start time to the phone's local time zone.
- Caches the last successful response so the widget can still display race information offline.
- Requests a schedule refresh when the widget is added and every six hours when Android can run background work.
- Refreshes after device time/date/time-zone changes, reboot, app updates, and widget resizing.
- Dark, red-accented resizable widget with race name, venue, local date/time, and countdown.
- Tap the race title or footer to open the official Formula 1 calendar.
- Version 2.2 adds an offline circuit outline beside the race details, selected using the schedule's circuit ID. It includes 26 circuits, covers every circuit in the fetched 2026 schedule, and hides on widths below 320dp or for an unknown circuit. Existing caches gain the circuit ID on the next successful schedule refresh.
- Circuit outlines are adapted from the MIT-licensed bacinger/f1-circuits dataset. The full attribution and license are bundled in `app/src/main/assets/circuit-layouts-LICENSE.txt`. Future track changes may require an asset update.

## Build and install
1. Keep the existing GitHub Actions workflow and this ZIP's filename and folder structure.
2. In GitHub, open Actions → Build F1 Next Race APK → Run workflow and select the fixes branch.
3. Wait for a successful build. The build runs the widget regression tests before completing.
4. Download the `F1-Next-Race-APK-Fixed` artifact, extract it, and install `app-debug.apk` on the phone.
5. Long-press the home screen → Widgets → F1 Next Race to add the widget if needed.

The existing workflow applies the RemoteViews decorative-view compatibility patch and Java 17 settings after extraction. Use that workflow when building this source ZIP.

## Update behavior and limitations
- Android controls the exact timing of periodic work; six hours is a requested interval, not a guaranteed exact refresh time.
- Network access is required for schedule updates. The last successful schedule is retained for offline display.
- Race times come from the Jolpica/Ergast-compatible schedule API. If the service is unavailable or changes its format, the widget keeps the cached data and retries later.
- This project is source code, not a precompiled APK.
- The native Android clock ticks while the widget is visible without waiting for network updates. `START • -3:09:00` means 3 hours and 9 minutes until the scheduled start. It reaches zero and then displays elapsed time since that scheduled start. Longer intervals use total hours rather than separate days.
- This is a scheduled-start clock, not confirmation that the race has actually begun. Delayed starts and live standings require a separate live data source, which is not included in this release. The existing schedule selection moves to the next future race on a successful schedule refresh.
- The clock follows the device's time. Enable automatic date and time on the phone for accurate alignment with real time.
- The footer keeps a dedicated row; title and text sizing adapt within the widget's supported minimum size. Verify the result on the actual Pixel launcher after installing.
- Check the official F1 calendar for last-minute schedule changes: https://www.formula1.com/en/racing/2026.html
