# F1 Next Race Widget — Pro

A native Android home-screen widget for the next Formula 1 Grand Prix.

## Features
- Fetches the current season race schedule from the community-maintained Jolpica F1 API.
- Finds the next race with a future start time.
- Converts the start time to the phone's local time zone.
- Caches the last successful response so the widget can still display race information offline.
- Requests a schedule refresh when the widget is added and every six hours when Android can run background work.
- Refreshes after device time/date/time-zone changes.
- Dark, red-accented resizable widget with race name, venue, local date/time, and countdown.
- Tap the race title or footer to open the official Formula 1 calendar.

## Build and install
1. Install Android Studio on Windows.
2. Extract this ZIP and open the `F1NextRaceWidgetPro` folder in Android Studio.
3. Let Gradle sync and download the WorkManager dependency.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press **Run** to build and install.
6. On the phone, long-press the home screen → **Widgets** → **F1 Next Race** → add the widget.

## Update behavior and limitations
- Android controls the exact timing of periodic work; six hours is a requested interval, not a guaranteed exact refresh time.
- Network access is required for schedule updates. The last successful schedule is retained for offline display.
- Race times come from the Jolpica/Ergast-compatible schedule API. If the service is unavailable or changes its format, the widget keeps the cached data and retries later.
- This project is source code, not a precompiled APK.
- The widget countdown updates when Android refreshes the widget or the app refresh worker runs, not every second.
- Check the official F1 calendar for last-minute schedule changes: https://www.formula1.com/en/racing/2026.html
